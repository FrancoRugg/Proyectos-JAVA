package demo_recursividad_b;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 * @author eduardo.perez
 */
public class menu {
    
    public void iniciar() {
        
        // ****** factorial iterativo
        System.out.println("------------------------");
        Scanner entry = new Scanner(System.in);
        System.out.println("Calculo de factorial");
        factorial fac = new factorial();
        System.out.println("Ingrese un entero:");
        int num = entry.nextInt();
        System.out.println(fac.fact_recursivo(num));
        
        
        // ****** factorial recursivo
        
        
        // ****** paridad
        System.out.println("");
        System.out.println("------------------------");
        System.out.println("Calculo de paridad");
        paridad parid = new paridad();
        
        System.out.println("Ingrese un entero:");
        int par = entry.nextInt();
        System.out.println(parid.esimpar(par));
        System.out.println(parid.espar(par));
        
        
        
        
        // ****** fibonaci
        System.out.println("");
        System.out.println("------------------------");
        System.out.println("Calculo de fibonaci");
        fibonaci fib = new fibonaci();
        System.out.println("Ingrese un entero:");
        int fi = entry.nextInt();
        System.out.println("La serie fibonaci de nNum:");
        
        System.out.println(fib.calcula_fibonaci(fi));
        // for (int i = 0; i < nNum; i++) {
 
        
        // ****** orden inverso
        System.out.println("");
        System.out.println("------------------------");
        System.out.println("Calculo de orden inverso");
        orden_inverso order = new orden_inverso();
        order.imp_OrdenInverso(5);
        
        // ****** cuenta regresiva
        System.out.println("");
        System.out.println("------------------------");
        System.out.println("Calculo de cuenta regresiva");
        regresiva regr = new regresiva();
        System.out.println("Ingrese un entero:");
        int r = entry.nextInt();
        regr.cuentaRegresiva(r);
        
    }
    
    public static String EliminarNotaciónCientífica(double número) {
        String d = "####################################";
        return new DecimalFormat("#." + d + d + d).format(número);
    }

}
