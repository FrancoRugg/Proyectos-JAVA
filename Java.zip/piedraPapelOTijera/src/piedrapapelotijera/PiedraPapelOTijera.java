/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package piedrapapelotijera;

import java.util.Scanner;
//import java.util.Random;

/**
 *
 * @author fruggiero
 */
public class PiedraPapelOTijera {

    /**
     * @param args the command line arguments
     */
        static final int piedra = 0;
        static final int papel = 1;
        static final int tijera = 2;
        static  Scanner entry = new Scanner(System.in);
        static int jugadorA = 0;
        static int jugadorB = 0;

    public static void win( int jugadorA){
        if (jugadorA == 5) {
            System.out.println("gano A");
        } else{
            System.out.println("gano B");
        }
        
    }
    public static void jugarPartida(){


        while (jugadorA < 5 && jugadorB < 5) {
            int randomNumber = obtenerJugadaPc();
            System.out.println("Piedra, Papel o Tijera? : ");
            obtenerNombreJugada();
//        randomNumber = entry.nextInt();
            if (sumaPuntosB(obtenerNombreJugada(), obtenerJugadaPc())) {
                jugadorB += 1;
                System.out.println("Punto para el B con " + randomNumber);
            } else if (jugadorA == 1 && randomNumber == 0 || jugadorA == 2 && randomNumber == 1 || jugadorA == 0 && randomNumber == 1) {
                jugadorA += 1;
                System.out.println("Punto para el A, el jugadorB jugó  " + jugadorB);

            } else {
                System.out.println("Empate! contiuara...");
            }
            System.out.println("Los resultados son : -jugador A con " + jugadorA + " puntos! y el Jugador B con " + jugadorB);
        }
        win();
        
    }
    
    public static int obtenerJugadaPc(){
        return (int) (Math.random() * 3);
    }
            
    public static int obtenerNombreJugada(int jugadaA ){
        
        return entry.nextInt();
        
    }
    
    public static void sumaPuntosB(int jugadoA, int jugadorB){
       return (jugadorA == piedra && randomNumber == papel || jugadorA == papel && randomNumber == tijera || jugadorA == tijera && randomNumber == piedra);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here


    }

 

   

}
