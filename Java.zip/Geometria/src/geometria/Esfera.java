/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package geometria;

/**
 *
 * @author fruggiero
 */
public class Esfera extends Shape3D{

    @Override
    public void calcularSurfaceArea(float radio) {
        float area = (float) ((4* Math.PI) * (radio*radio));
        System.out.println("El area de la esfera es de : " + area);
    }

    @Override
    public void calcularVolumen(float radio) {
        float vol = (float) (((4/3)* Math.PI) * (radio*radio*radio));
        System.out.println("El volumen de la esfera es de : " + vol);
    }
    
}
