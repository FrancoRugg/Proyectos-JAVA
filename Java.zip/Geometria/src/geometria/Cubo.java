/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package geometria;

/**
 *
 * @author fruggiero
 */
public class Cubo extends Shape3D{
    @Override
    public void calcularVolumen(float lado) {
        float vol = (lado*lado*lado);
        System.out.println("El volumen del Cubo es de : " + vol);
    }

    @Override
    public void calcularSurfaceArea(float lado) {
        float area = (lado * lado )*6;
        System.out.println("El area del Cubo es de : " + area);

    }
}
