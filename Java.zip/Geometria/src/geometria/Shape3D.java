/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package geometria;

/**
 *
 * @author fruggiero
 */
public abstract class Shape3D {
    public abstract void calcularVolumen(float valor);
    public abstract void calcularSurfaceArea(float valor);
}
