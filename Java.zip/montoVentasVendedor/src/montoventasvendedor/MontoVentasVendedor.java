/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package montoventasvendedor;
import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class MontoVentasVendedor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingrese Su Nombre: ");
        String nombre   = entrada.nextLine();
        
        System.out.println("Ingrese el monto Recaudado: ");
        int mensualidad = entrada.nextInt();
        
        System.out.println("Ingrese cuantos dias falto: ");
        int dias        = entrada.nextInt();
        
        if (mensualidad < 100000 || dias > 5 ){
        
                System.out.println("El vendedor " + nombre + " no cumple con los requisitos");
               
        }else if(mensualidad >= 200000){
        
                System.out.println("El vendedor " + nombre + " tiene que cobrar el bono x2");
                
        }else{
                
                System.out.println("El vendedor " + nombre + " tiene que cobrar el bono comun");
                
        }
  
        
        //Debug se hace con F5, para ver donde ocurre el error.
        
        
        //Teatro
        /*
        
        Entrada sale $2000
        Menores de 8, no pagan
        Mayores de 60, pagam la mitad
        Entre 8 a 60, pagan entrada general
        
        */
        
        Scanner teatro = new Scanner(System.in);
        
        int entry    = 2000;
        
        System.out.println("Ingrese su edad: ");
        int edad       = teatro.nextInt();
        
        if(edad < 8){
            
            System.out.println(" Free entry");
            
        }else if(edad > 60){
            
            System.out.println("Pagas un total de $" + (entry / 2));
            
        }else{
            
            System.out.println("El valor de la entrada es de $" + entry);
            
        }
        
    }
    
}
