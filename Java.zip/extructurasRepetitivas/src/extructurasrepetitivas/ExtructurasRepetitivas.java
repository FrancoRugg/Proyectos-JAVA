/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package extructurasrepetitivas;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class ExtructurasRepetitivas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
            System.out.println("Ejercicio R03");
            
            Scanner fruta = new Scanner(System.in);
            
            System.out.println("Ingresá una fruta: ");
            String fruit = fruta.nextLine();
            
             for( int o = 0; o < 10; o++){
        
                System.out.println("La fruta es: " + fruit );
            
            }
        
    }
        
    }
    

