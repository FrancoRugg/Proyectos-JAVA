/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalexample;

/**
 *
 * @author fruggiero
 */
public abstract class post {
    //siempre protejido, se puede utilizar de las clases heredadas
    protected String title;
    protected float referencePrice;

    public post(String title, float referencePrice) {
        this.title = title;
        this.referencePrice = referencePrice;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public float getReferencePrice() {
        return referencePrice;
    }

    public void setReferencePrice(float referencePrice) {
        this.referencePrice = referencePrice;
    }
    
    public abstract float calculateSalePrice();
}
