/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package finalexample;

/**
 *
 * @author fruggiero
 */
public class FinalExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PaperBook pb = new PaperBook("tuki", 10000, 1000);
        PaperBook pb2 = new PaperBook("tuki2", 10000, 999);
        
        pb.calculateSalePrice();
        System.out.println(pb.toString());
        pb2.calculateSalePrice();
        System.out.println(pb2.toString());
        
        System.out.println("---------------------------");
        AudioBook ab = new AudioBook("sac", 10000, 230);
        AudioBook ab2 = new AudioBook("sac2", 10000, 120);
        
        ab.calculateSalePrice();
        System.out.println(ab.toString());
        ab2.calculateSalePrice();
        System.out.println(ab2.toString());
        
        
    }
    
}
