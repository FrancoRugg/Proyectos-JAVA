/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalexample;

/**
 *
 * @author fruggiero
 */
public class PaperBook extends post{

    private int pages;
    
    public PaperBook(String title, float referencePrice, int pages) {
        super(title, referencePrice);
        this.pages = pages;
    }

    public int getPages() {
        return pages;
    }

    public void setPages(int pages) {
        this.pages = pages;
    }

    @Override
    public float calculateSalePrice() {
        if(pages < 1000){
          return referencePrice;
        }
        return referencePrice += (referencePrice * 0.1);
    }

    @Override
    public String toString() {
        return "PaperBook{" + "pages : " + pages + " salePrice : " + calculateSalePrice() + '}';
    }
    
    
    
}
