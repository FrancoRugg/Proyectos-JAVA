/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package finalexample;

/**
 *
 * @author fruggiero
 */
public class AudioBook extends post{

    private int audioTime;
    public AudioBook(String title, float referencePrice, int audioTime) {
        super(title, referencePrice);
        this.audioTime = audioTime;
    }

    @Override
    public float calculateSalePrice() {
        return referencePrice -= (referencePrice * 0.15);
    }
    
    @Override
    public String toString() {
        return "AudioBook{" + "audioTime: " + audioTime + " salePrice : " + calculateSalePrice() + '}' ;
    }
    

    
}
