/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciarrhh;

/**
 *
 * @author fruggiero
 */
public class puestoJerarquico extends Empleado{
    private String sector;

    public puestoJerarquico(String name, int dni, int employType, float grossSalary, String sector) {
        super(name, dni, employType, grossSalary);
        this.sector = sector;
    }
    
    @Override
    public String getEmploy(){
        return super.getEmploy() + "- Sector: " + sector;
    }
}
