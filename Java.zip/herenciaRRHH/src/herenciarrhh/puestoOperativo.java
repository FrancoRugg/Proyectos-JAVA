/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciarrhh;

/**
 *
 * @author fruggiero
 */
public class puestoOperativo extends Empleado{
    private int assembledProducts; 
    private int faults; 
    
    public puestoOperativo(String name, int dni, int employType, float grossSalary, int assembledProducts, int faults) {
        super(name, dni, employType, grossSalary);
        this.assembledProducts = assembledProducts;
        this.faults = faults;
        setGrossSalary(0);
    }
    
    @Override
    public String getEmploy(){
        return super.getEmploy() + "- Productos Armados: " + assembledProducts + "- Faltas: " + faults;
    }
    @Override
    public void setGrossSalary(float grossSalary) {
        if(assembledProducts > 1000 && faults <= 20){
            this.grossSalary += (this.grossSalary * 0.25);
        }else{
            this.grossSalary = this.grossSalary;
        }
    }
}
