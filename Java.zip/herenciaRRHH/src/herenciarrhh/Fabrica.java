/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciarrhh;

import java.util.ArrayList;

/**
 *
 * @author fruggiero
 */
public class Fabrica {
    private ArrayList<Empleado> employs;
    
    public Fabrica(){
        employs = new ArrayList<>();
    }

    public void addEmploy(Empleado employ) {
        employs.add(employ);
    }
    public void deleteEmploy(Empleado employ) {
        employs.remove(employ);
    }
    
    public void listEmploys(){
        System.out.println("Todos los empleados ");
        for (int i = 0; i < employs.size(); i++) {
            String get = employs.get(i).getEmploy();
            System.out.println(get);
        }
    }
    public void listEmploysHierarchical(){
        boolean type = false;
        System.out.println("Empleados Jerarquicos ");
        for (int i = 0; i < employs.size(); i++) {
            type = true;
            int get = employs.get(i).getEmployType();
            String got = employs.get(i).getEmploy();
            if(get == 3){
                System.out.println(got);
            }
        }
    }
   
    public void listEmploysAdministrative(){
        boolean type = false;
        System.out.println("Empleados Administrativos ");
        for (int i = 0; i < employs.size(); i++) {
            type = true;
            int get = employs.get(i).getEmployType();
            String got = employs.get(i).getEmploy();
            if(get == 2){
                System.out.println(got);
            }
        }
    }
    public void listEmploysOperator(){
        boolean type = false;
        System.out.println("Empleados Operativo ");
        for (int i = 0; i < employs.size(); i++) {
            type = true;
            int get = employs.get(i).getEmployType();
            String got = employs.get(i).getEmploy();
            if(get == 1){
                System.out.println(got);
            }
        }
    }

    public ArrayList<Empleado> getEmploys() {
        return employs;
    }

    public void setEmploys(ArrayList<Empleado> employs) {
        this.employs = employs;
    }
    
    
    
    
    
}
