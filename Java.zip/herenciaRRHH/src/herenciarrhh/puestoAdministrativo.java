/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciarrhh;

/**
 *
 * @author fruggiero
 */
public class puestoAdministrativo extends Empleado{
    private int antiquity;
    public puestoAdministrativo(String name, int dni, int employType, float grossSalary, int antiquity) {
        super(name, dni, employType, grossSalary);
        this.antiquity = antiquity;
        setGrossSalary(0);
    }
    
    @Override
    public String getEmploy(){
        return super.getEmploy() + "- Antiguedad: " + antiquity;
    }
    
    @Override
    public void setGrossSalary(float grossSalary) {
        if(antiquity < 5){
            this.grossSalary = this.grossSalary;
        }else if(antiquity >= 5 && antiquity <= 10){
            this.grossSalary += (this.grossSalary * 0.1);
        }else if(antiquity > 10 && antiquity <= 20){
            this.grossSalary += (this.grossSalary * 0.2);
        }else if(antiquity > 20 && antiquity <=31){
            this.grossSalary += (this.grossSalary * antiquity) / 100;
        }else{
            this.grossSalary += (this.grossSalary * 0.31);
        }
    }
}
