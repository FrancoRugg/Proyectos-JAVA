/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package herenciarrhh;

/**
 *
 * @author fruggiero
 */
public class HerenciaRRHH {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fabrica fabric = new Fabrica();
        System.out.println("---------------------------");
        
//        Empleado employ = new Empleado("Alfred", 12343567, 1, 400000);
        puestoOperativo employ = new puestoOperativo("Alfred", 12343567, 1, 400000, 200, 0);
//        Empleado employ2 = new Empleado("Frida", 12343567, 1, 400000);
        puestoOperativo employ2 = new puestoOperativo("Frida", 12343567, 1, 400000, 1001, 21);
//        Empleado employ3 = new Empleado("Peterson", 12343567, 1, 400000);
        puestoOperativo employ3 = new puestoOperativo("Peterson", 12343567, 1, 400000, 1100,5);
        
//        Empleado employ4 = new Empleado("Mister", 123435367, 2, 360000);
        puestoAdministrativo employ4 = new puestoAdministrativo("Mister", 0, 2, 360000, 5);
//        Empleado employ5 = new Empleado("Mongomery", 123435367, 2, 360000);
        puestoAdministrativo employ5 = new puestoAdministrativo("Mister", 0, 2, 360000, 6);
//        Empleado employ6 = new Empleado("Homer", 123435367, 2, 360000);
        puestoAdministrativo employ6 = new puestoAdministrativo("Mister", 0, 2, 360000, 11);
        puestoAdministrativo employ7 = new puestoAdministrativo("Mister", 0, 2, 360000, 22);
        puestoAdministrativo employ8 = new puestoAdministrativo("Mister", 0, 2, 360000, 31);
        
//        Empleado employ7 = new Empleado("Patursito", 123435627, 3, 150000);
        puestoJerarquico employ9 = new puestoJerarquico("Patursito", 0, 3, 360000, "ventas");
        puestoJerarquico employ10 = new puestoJerarquico("Patursito", 0, 3, 360000, "ventas");
        puestoJerarquico employ11 = new puestoJerarquico("Patursito", 0, 3, 360000, "ventas");
//        Empleado employ8 = new Empleado("Moria", 123435627, 3, 150000);
//        puestoJerarquico employ10 = new puestoJerarquico(name, 0, 0, 0, sector);
//        Empleado employ9 = new Empleado("L-gante", 123435627, 3, 150000);
//        puestoJerarquico employ11 = new puestoJerarquico(name, 0, 0, 0, sector);
        
        fabric.addEmploy(employ);
        fabric.addEmploy(employ2);
        fabric.addEmploy(employ3);
        fabric.addEmploy(employ4);
        fabric.addEmploy(employ5);
        fabric.addEmploy(employ6);
        fabric.addEmploy(employ7);
        fabric.addEmploy(employ8);
        fabric.addEmploy(employ9);
        fabric.addEmploy(employ10);
        fabric.addEmploy(employ11);
        
        fabric.listEmploys();
        fabric.listEmploysHierarchical();
        fabric.listEmploysAdministrative();
        fabric.listEmploysOperator();
        
        
    }
    
}
