/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herenciarrhh;

import java.util.ArrayList;

/**
 *
 * @author fruggiero
 */
public class Empleado {
    private String name;
    private int dni;
    private int employType; //1 - operarios, 2- administrativos y 3 - jerárquicos
    protected float grossSalary;
    

    public Empleado(String name, int dni, int employType, float grossSalary) {
        this.name = name;
        this.dni = dni;
        this.employType = employType;
        this.grossSalary = grossSalary;
    }
    
    public float getNetIncome(){
         return this.grossSalary = (float) (grossSalary * 0.17);
    }
    
    public String getEmploy(){
        String employeeTypeString = (employType == 2)? "Administrativo":(employType == 1) ? "Operario" : "Jerarquico";
        return "Name: " + name + "- Dni: " + dni + "- Employ Type: " + employeeTypeString + "- Gross Salary: " + grossSalary + "- Net Income: " + getNetIncome();
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getEmployType() {
        return employType;
    }

    public void setEmployType(int employType) {
        this.employType = employType;
    }

    public float getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(float grossSalary) {
        this.grossSalary = grossSalary;
    }
    
}
