/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aprobado;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Aprobado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sets   = new Scanner(System.in);
        
        System.out.println("Insertar Puntaje Jugador A: ");
        int jugadorA = sets.nextInt();
        
        System.out.println("Insertar Puntaje Jugador B: ");
        int jugadorB = sets.nextInt();
        
        
        /*if(jugadorA >7 || jugadorB >7 || jugadorB == 7 && jugadorA == 7 || jugadorA == 7 && jugadorB ==4 
                       || jugadorB == 7 && jugadorA ==4 || jugadorA == 7 && jugadorB ==3 || jugadorB == 7 && jugadorA ==3 
                       || jugadorA == 7 && jugadorB ==2 || jugadorB == 7 && jugadorA ==2 || jugadorA == 7 && jugadorB ==1 
                       || jugadorB == 7 && jugadorA ==1 || jugadorA == 7 && jugadorB ==0 || jugadorB == 7 && jugadorA ==0){*/
        if(jugadorA >7 || jugadorB >7 || jugadorB == 7 && jugadorA == 7 || jugadorA == 7 && jugadorB <= 4 
                       || jugadorB == 7 && jugadorA <= 4 ){        
            
            System.out.println("Resultado invalido");
                    
        }else if(jugadorB <=6 && jugadorA >6 && jugadorA <=7){
       
            System.out.println("Jugador A ganó");
        
        }else if(jugadorA <=6 && jugadorB >6 && jugadorB <=7){
        
            System.out.println("Jugador B ganó");
            
        }else if(jugadorA <=6 && jugadorB <=6 ){
            
            System.out.println("No finalizó el set");
       
    }
    
        }}


