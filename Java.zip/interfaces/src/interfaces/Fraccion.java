/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Fraccion implements Relacion{
        private int number;
        private int number2;

    public Fraccion(int number, int number2) {
        this.number = number;
        this.number2 = number2;
    }
    @Override
    public boolean esMayorQue(Relacion a) {        
        if(((Fraccion)a).getFractionToNumber() > getFractionToNumber()){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean esMenorQue(Relacion a) {
        if(((Fraccion)a).getFractionToNumber() < getFractionToNumber()){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean esIgualQue(Relacion a) {
        if(((Fraccion)a).getFractionToNumber() == getFractionToNumber()){
            return true;
        }else{
            return false;
        }
    }
    
    public float getFractionToNumber(){
        return (float)number /(float)number2;
    }
    
}
