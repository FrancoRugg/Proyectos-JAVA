/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaces;

/**
 *
 * @author fruggiero
 */
public class Interfaces {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Fraccion one = new Fraccion(1, 3);
        Fraccion two = new Fraccion(3, 4);
        System.out.println("-------------");
        System.out.println(one.getFractionToNumber());
        System.out.println(two.getFractionToNumber());
        
        System.out.println("Es mayor : " + one.esMayorQue(two));
        
        
        Fraccion three = new Fraccion(2, 5);
        Fraccion four = new Fraccion(7, 9);
        System.out.println("-------------");
        System.out.println(three.getFractionToNumber());
        System.out.println(four.getFractionToNumber());

        
        System.out.println("Es menor : " + three.esMenorQue(four));
        
        
        Fraccion five = new Fraccion(56, 6);
        Fraccion six = new Fraccion(56, 6);
        System.out.println("-------------");
        System.out.println(five.getFractionToNumber());
        System.out.println(six.getFractionToNumber());
        System.out.println("Es igual : " + five.esIgualQue(six));
        
        
    }
    
}
