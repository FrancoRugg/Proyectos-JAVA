/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fechadenacimiento;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class baraja {
    
    String Alumno = "Franco Ruggiero";
    
    int cantidad_cartas;
    int profesional;
    int amateur;
    String color_reverso;
    
    
        Scanner barajas = new Scanner(System.in);
        System.out.println("Ingresá cantidad de cartas junto a su color: ");
        this.cantidad_cartas = barajas.nextInt();
        this.color_reverso   = barajas.nextLine();
        
        
        if( this.cantidad_cartas == 50 && this.color_reverso == "rojo"){
            System.out.println("Es un maso Amateur  ");
        }else if(this.cantidad_cartas <= 50 && this.cantidad_cartas >= 40 && this.color_reverso != "rojo"){
            System.out.println("Es un maso Profesional"); 
        }
        
        

                
    
}