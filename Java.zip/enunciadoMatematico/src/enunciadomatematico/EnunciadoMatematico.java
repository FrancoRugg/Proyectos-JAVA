/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package enunciadomatematico;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class EnunciadoMatematico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entry = new Scanner(System.in);

          System.out.println("Ingresa un número :" );
          int number = entry.nextInt();
        while(number > 1){
            
        if( number % 2  == 0){
            number = number / 2;
            System.out.println(number);
        }else{
            number = (number * 3) + 1;
            System.out.println(number);
        }
            
        }
    }
    
}
