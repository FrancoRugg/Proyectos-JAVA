/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package d16pilastack;

/**
 *
 * @author fruggiero
 */
public class D16PilaStack {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        pilaStack ps = new pilaStack();
        ps.addDatos();//Esta sola hace todos
//        ps.printDatos();
//        ps.takeDatos();
    }
    
}
