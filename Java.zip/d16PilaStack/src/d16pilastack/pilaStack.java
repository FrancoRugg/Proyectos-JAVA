/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package d16pilastack;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author fruggiero
 */
public class pilaStack {
    ArrayList<Object> arr = new ArrayList<>();
    public void addDatos(){
        Scanner entry  = new Scanner(System.in);
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Ingrese un valor : ");
            Object valor = entry.nextLine();
            arr.add(valor);
            
        }
        
        Stack<Object> s = new Stack<>();
        for (int i = 0; i < 10; i++) {
            s.push(arr.get(i));
        }
        
        System.out.println("--------------------------");
        
        while (!s.empty()) {
            System.out.println(s.pop());
        }
    }
    
    public void printDatos(){
        for (int i = 0; i < arr.size(); i++) {
            Object get = arr.get(i);
            System.out.println("Elemento del ArrayList : " + get);
        }
    }
    
    public void takeDatos(){
        for (int i = 0; i < arr.size(); i++) {
            Object get = arr.get(i);
            arr.remove(i);
            System.out.println("Elemento eliminado del ArrayList : " + get);
        }
    }
    
}
