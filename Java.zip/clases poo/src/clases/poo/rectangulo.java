/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clases.poo;

/**
 *
 * @author fruggiero
 */
public class rectangulo {
    private int base;
    private int altura;
    
    //Constructor parametrizado
    public rectangulo( int base, int altura){
        this.base = base;
        this.altura = altura;
    }
    //Constructor por defecto
    public rectangulo( ){
        
    }
    
    //setters

    public void setBase(int base) {
        this.base = base;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
    
    //getters

    public int getBase() {
        return base;
    }

    public int getAltura() {
        return altura;
    }
    
    //Métodos
    
    public int calcularPerimetro(){
        return 2 * altura + 2 * base;
    }
    public int cslcularArea(){
        return base * altura;
    }
    public boolean esCuadrado(){
//       return base == altura ? true : false;
       return base == altura;
    }
    
    
    
    
    
    
}
