/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clases.poo;

import java.awt.BorderLayout;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ClasesPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entry = new Scanner(System.in);
        System.out.println("Ingresà la base :");
        int base = entry.nextInt();
        System.out.println("Ingresà la altura :");
        int altura = entry.nextInt();
        
        rectangulo rec = new rectangulo(base,altura);
        
//        rec.altura = (altura);
//        rec.base= (base);
        
        int perimetro = rec.calcularPerimetro();
        System.out.println("El perimetro es de : " + perimetro);
        
        int area = rec.cslcularArea();
        System.out.println("El area es de : " + area);
        
        boolean cuadrado = rec.esCuadrado();
        if(cuadrado){
            System.out.println("'El rectangulo tiene base y altura diferentes'");
        }else{
            System.out.println("'Es rectangulo tiene sus lados iguales'");
        }        
        
    }
    
}
