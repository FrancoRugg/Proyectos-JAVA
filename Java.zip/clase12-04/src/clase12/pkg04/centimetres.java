/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clase12.pkg04;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class centimetres {
    
    public void solution(){
        
        //            Cm a Pulgadas

        Scanner conversor   = new Scanner(System.in);
            
            System.out.println("Write in Cm: ");
            double Cm       = conversor.nextDouble(); //poner double así toma los numeros con coma
            
            double pulgada  = Cm / 2.54;
            
            System.out.println("Rest in pulgada : " + pulgada);
        
    }
    
}
