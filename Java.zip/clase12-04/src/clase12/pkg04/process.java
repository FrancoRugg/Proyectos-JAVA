/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clase12.pkg04;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class process {
    
    public void solution() {

    //Positivo Negativo
        
            Scanner neg     = new Scanner(System.in);
            
            System.out.println("Ingresá un número: ");
            int pos = neg.nextInt();
            
            if(pos == 0){
             
                System.out.println("El número es Cero");
                
            }else if(pos > 0){
            
                System.out.println("El número es Positivo");
            
            }else{
            
                System.out.println("El número es Negativo");
            
            }
            }
          

}
    

