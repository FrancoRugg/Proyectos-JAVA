/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase12.pkg04;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Clase1204 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // responder cual seria el valor de resultado
        
        process miProcess = new process();
        miProcess.solution();
        
        centimetres miCentimetres = new centimetres();
        miCentimetres.solution();


        int resultado = 0;
        
        int numa = 5;
        int numb = 20;
        
        boolean log1 = true;
        boolean log2 = false;

        if (numa == 5){
            resultado = resultado + 1;
        }
       
       if (numa == 7){
            resultado = resultado + 2;
        }
        
        if (numa == 5 || numb == 32){
            resultado = resultado + 3;
        }
        
        if (numa == 5 || numb == 20){
            resultado = resultado + 4;
        }

        if (numa == 5 || numb == 20){
            resultado = resultado + 5;
        }
        
        
        if (numa == 5 && numb == 20){
            resultado = resultado + 6;
        }
        
        if (numa == 20 && numb == 5){
            resultado = resultado + 7;
        }
        
        if (log1){
            resultado = resultado + 8;
        }

        if (log1 == false){
            resultado = resultado + 9;
        }

        if ((!log1) == false){
            resultado = resultado + 10;
        }

        if (log1 == true || log2 == false){
            resultado = resultado + 11;
        }
        
        if (log1 == true && log2 == true){
            resultado = resultado + 12;
        }
        
        if (log1 == true && numa > 3){
            resultado = resultado + 13;
        }

        if (log2 == false || numa > 3){
            resultado = resultado + 14;
        }        

        if (log2 == false || numa > 7 || numb == 20){
            resultado = resultado + 15;
        }
        
        if (log1 == true && numa > 3 && numb < 200 && log2 == false){
            resultado = resultado + 16;
        }
        
        if (log1 == numb > numa) {
            resultado = resultado + 17;
        }
  
        if (log2 == numb > numa) {
            resultado += 18;
        
        }
        
        System.out.println(resultado);
        
        
    
  //modulo5
  
//            Scanner modul    = new Scanner (System.in);
//                    
//            
//            System.out.println("Ingresá un número: ");
//            int num          = modul.nextInt();
//    }

    }}
    

