/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poo;

/**
 *
 * @author fruggiero
 */
public class prueba {
    
    public void pruebacontacto(){
        
       contacto c1 = new contacto("Franco", "Calle falsa 123", "1140474809");
        
        System.out.println(c1.getNombre());
        System.out.println(c1.getDireccion());
        System.out.println(c1.getTelefono());
    }
    
}
