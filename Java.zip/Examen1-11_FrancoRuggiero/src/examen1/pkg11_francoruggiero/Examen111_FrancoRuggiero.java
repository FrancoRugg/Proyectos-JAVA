/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen1.pkg11_francoruggiero;

/**
 *
 * @author fruggiero
 */
public class Examen111_FrancoRuggiero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Ejercicio 101 Franco Ruggiero");
        Proceso p = new Proceso();
        System.out.println("Osvaldo está : "+p.SeEncuentraOsvaldo());
        System.out.println("--------------------");
        System.out.println("Ejercicio 103 Franco Ruggiero");
        buscaRepetidos bp = new buscaRepetidos();
        bp.proceso();
    }
    
}
