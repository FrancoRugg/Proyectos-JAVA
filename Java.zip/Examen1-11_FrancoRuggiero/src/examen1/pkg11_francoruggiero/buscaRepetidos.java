/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1.pkg11_francoruggiero;

import java.util.ArrayList;

/**
 *
 * @author fruggiero
 */
public class buscaRepetidos { 
    public ArrayList<Integer> lista1 = new ArrayList<>();
    public ArrayList<Integer> lista2 = new ArrayList<>();
     public void proceso() { 
         for (int i=20; i<=28; i++){
         lista1.add(i);
        }
         for (int i=25; i<=32; i++) {
             lista2.add(i); 
         }
         try {
            ArrayList<Integer> repe = buscaRepe(lista1, lista2);

            System.out.println("Elementos repetidos:" + repe.toString()); 
         } catch (IndexOutOfBoundsException e) {
             e.printStackTrace();
         }
     } 
    public ArrayList<Integer> buscaRepe(ArrayList<Integer> par1, ArrayList<Integer> par2){
        ArrayList<Integer> repetidos = new ArrayList<>(); // implementar logica pedida return repetidos; } }
            for (int i = 0; i < par1.size(); i++) {
                Integer par1Get = par1.get(i);
                for (int j = 0; j < par2.size(); j++) {
                    Integer par2Get = par2.get(j);
                    if(par1Get.equals(par2Get)){
                        repetidos.add(par1Get);
                    } 
                }
            }
        return repetidos;
    } 
}
