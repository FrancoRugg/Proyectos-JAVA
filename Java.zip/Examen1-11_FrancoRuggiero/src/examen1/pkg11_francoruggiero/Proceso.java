/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen1.pkg11_francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Proceso {
    public boolean SeEncuentraOsvaldo(){
        String nombre = "osvaldo";
        Scanner entry = new Scanner(System.in);
        System.out.println("Ingrese un texto:");
        String frase = entry.nextLine();
        if(frase.contains(nombre)){
            return true;
        }else{
            return false;
        }
    }
}
