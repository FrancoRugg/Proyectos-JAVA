package demo_recursividad_2;

public class Demo_recursividad_2 {

    public static void main(String[] args) {
        
        menu men = new menu();
        men.iniciar();

    }
    
}
