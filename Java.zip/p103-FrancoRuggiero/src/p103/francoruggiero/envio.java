/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p103.francoruggiero;

/**
 *
 * @author fruggiero
 */
public class envio {
    int id;
    String dereccionFacturacion;
    boolean finalizado;
    int fechaEnvio;
    String compania;

    public int getId() {
        return id;
    }

    public String getDereccionFacturacion() {
        return dereccionFacturacion;
    }

    public boolean isFinalizado() {
        return finalizado;
    }

    public int getFechaEnvio() {
        return fechaEnvio;
    }

    public String getCompania() {
        return compania;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDereccionFacturacion(String dereccionFacturacion) {
        this.dereccionFacturacion = dereccionFacturacion;
    }

    public void setFinalizado(boolean finalizado) {
        this.finalizado = finalizado;
    }

    public void setFechaEnvio(int fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }

    public void setCompania(String compania) {
        this.compania = compania;
    }

    @Override
    public String toString() {
        return "envio{" + "id=" + id + ", dereccionFacturacion=" + dereccionFacturacion + ", finalizado=" + finalizado + ", fechaEnvio=" + fechaEnvio + ", compania=" + compania + '}';
    }
    
    
}
