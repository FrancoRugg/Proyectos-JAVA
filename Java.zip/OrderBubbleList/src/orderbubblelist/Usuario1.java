/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package orderbubblelist;

import java.util.Arrays;

/**
 *
 * @author fruggiero
 */
public  class Usuario1 implements Comparable{
    private String nombre;
    private int edad;
    public static Usuario1[] usuarios = new Usuario1[5];
//        ArrayList <Usuario1> usuarios = new ArrayList<Usuario1>();

//        
    Usuario1(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    @Override
    public String toString() {
        return nombre + " (" + edad + ")";
    }
    
    //Para ordenar por nombre
    @Override
    public int compareTo(Object o) {
        Usuario1 otroUsuario = (Usuario1) o;
        //podemos hacer esto porque String implementa Comparable
        return nombre.compareTo(otroUsuario.getNombre());
    }


    public static void printList(){
        usuarios[0]=(new Usuario1("uno", 11));
        usuarios[1]=(new Usuario1("dos", 2));
        usuarios[2]=(new Usuario1("tres", 3));
        usuarios[3]=(new Usuario1("cuatro", 44));
        usuarios[4]=(new Usuario1("cinco", 45));
        System.out.println("Desordenado");
        for (int i = 0; i < 5; i++) {
            System.out.println(usuarios[i].toString());
        }
//        burbuja(usuarios);
        Arrays.sort(usuarios);
        System.out.println("Ordenado");
        for (int i = 0; i < 5; i++) {
            System.out.println(usuarios[i].toString());
        }
        
    }
    //Para ordenar por edad
//    public static void burbuja(Usuario1[] A) {
//        int i;
//        int j;
//        Usuario1 aux;
//        for (i = 0; i < A.length - 1; i++) {
//            for (j = 0; j < A.length - i - 1; j++) {                                                              
//                if (A[j + 1].getEdad() < A[j].getEdad()) {
//                    aux = A[j + 1];
//                    A[j + 1] = A[j];
//                    A[j] = aux;
//                }
//            }
//        }
//    }

}
