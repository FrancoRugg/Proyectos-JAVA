/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arrayslists;

/**
 *
 * @author fruggiero
 */
public class alumnos {
    private String name;
    private int yearsOld;
    private float promedy;
    private boolean beca;
    private String moreTreina;
    private String moreThanSeven;
    private String betweenFourAndSeven;
    private String withBecaAndLowerThanTwenty;

    public alumnos(String name, int yearsOld, float promedy, boolean beca) {
        this.name = name;
        this.yearsOld = yearsOld;
        this.promedy = promedy;
        this.beca = beca;
    }
    
    public String getAlumno(){
        String alumno = "- Name : " + this.name + "- Years old :" + this.yearsOld + "- Promedy : " + this.promedy + "- Beca : " + this.beca;
        return alumno;
    }
    
    public void moreTreina(int yearsOld , String name){
        if(yearsOld > 30){
            moreTreina+=name;
        }
    }
    public void moreThanSeven(int promedy , String name){
        if(promedy > 7){
            moreThanSeven+=name;
        }
    }
    public void betweenFourAndSeven(int promedy , String name){
        if(promedy > 4 && promedy < 7){
            betweenFourAndSeven+=name;
        }
    }
    public void withBecaAndLowerThanTwenty(boolean beca,int year, String name){
        if(beca && year < 20){
            withBecaAndLowerThanTwenty+=name;
        }
    }
    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getYearsOld() {
        return yearsOld;
    }

    public void setYearsOld(int yearsOld) {
        this.yearsOld = yearsOld;
    }

    public float getPromedy() {
        return promedy;
    }

    public void setPromedy(float promedy) {
        this.promedy = promedy;
    }

    public boolean isBeca() {
        return beca;
    }

    public void setBeca(boolean beca) {
        this.beca = beca;
    }
    
    
    
    
}
