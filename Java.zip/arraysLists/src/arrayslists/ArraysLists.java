/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrayslists;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ArraysLists {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList <alumnos> list = new ArrayList<>();
        Scanner entry = new Scanner(System.in);
//        ArrayList <alumnos> list = new ArrayList<>();
        
        String response = "y";
        String addAlumn;
        
        do{
            
            System.out.println("Ingrese en nombre: "); 
            String name = entry.nextLine();
            System.out.println("Ingrese edad: "); 
            int yearsOld = entry.nextInt();
            System.out.println("Ingrese el promedio del alumno: "); 
            float promedy = entry.nextInt();
            System.out.println("Ingrese si cuenta con beca: true or false"); 
//            String beca = entry.nextLine();
            boolean beca = entry.nextBoolean();
            
            alumnos person = new alumnos(name, yearsOld, promedy, beca);
            
            list.add(person);
            
            System.out.println("Desea agregar un alumo nuevo?"); 
            entry.nextLine();
            addAlumn = entry.nextLine();
            System.out.println("------------");
                    
            
        }while(addAlumn.equals(response));
        
//        list.forEach((unique) -> 
//                
//                System.out.println(unique)
////                if(unique.getAlumno() > 30){
////                    
////                }
//        );
        ArrayList<String> moreTreina = new ArrayList<>();
        ArrayList<String> moreThanSeven = new ArrayList<>();
        ArrayList<String> betweenFourAndSeven = new ArrayList<>();
        ArrayList<String> withBecaAndLowerThanTwenty = new ArrayList<>();

        for (alumnos alum: list) {
            System.out.println(alum.getAlumno());
            
            if(alum.getYearsOld() > 30){
                moreTreina.add(alum.getAlumno());
            }
            if(alum.getPromedy() > 7){
                moreThanSeven.add(alum.getAlumno());
            }
            if(alum.getPromedy() > 4 && alum.getPromedy() < 7){
                betweenFourAndSeven.add(alum.getAlumno());
            }
            if(alum.getYearsOld() > 30){
                moreTreina.add(alum.getAlumno());
            }
            if(alum.getYearsOld() < 20 && alum.isBeca() == true){
                withBecaAndLowerThanTwenty.add(alum.getAlumno());
            }
        }
        System.out.println("-------------------");
        if(!moreTreina.isEmpty()){
        System.out.println("Alumnos mayores de 30 : ");
        for (int i = 0; i < moreTreina.size(); i++) {
            System.out.println(moreTreina.get(i));
        }
        }
        if(!moreThanSeven.isEmpty()){
        System.out.println("-------------------");
        System.out.println("Alumnos con promedio > 7 : ");
        for (int i = 0; i < moreThanSeven.size(); i++) {
            System.out.println(moreThanSeven.get(i));
        }
        }
        if(!betweenFourAndSeven.isEmpty()){
        System.out.println("-------------------");
        System.out.println("Alumnos con promedios > 4 y < 7 : ");
        for (int i = 0; i < betweenFourAndSeven.size(); i++) {
            System.out.println(betweenFourAndSeven.get(i));
        }
        }
        if(!withBecaAndLowerThanTwenty.isEmpty()){
        System.out.println("-------------------");
        System.out.println("Alumnos con beca menores de 20 : ");
        for (int i = 0; i < withBecaAndLowerThanTwenty.size(); i++) {
            System.out.println(withBecaAndLowerThanTwenty.get(i));
        }
        }
        
        
        


        
        
        
        
        
        
    }
    
}
