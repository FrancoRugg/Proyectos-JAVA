/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo_excepciones;

/**
 *
 * @author eduardo
 */
public class Demo_excepciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ejemplo2 eje2 = new ejemplo2();
        
//         eje2.convierte_a_numero();
        
//         eje2.divide_por_cero();

         eje2.elemento_array();
        
//        eje2.divide_por_cero_tipo();

    }
    
}
