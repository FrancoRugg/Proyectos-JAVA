/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package añobisiesto;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class AñoBisiesto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Es biciesto si:
        //Es multiplo de 4, multiplo de 400
        //No lo es si es multiplo de 100
        
        Scanner entry = new Scanner(System.in);
        System.out.println("Ingrear año: ");
        int año = entry.nextInt();
        
        
        
        logica nuevo = new logica();
        
        nuevo.biciesto(año);
        if(nuevo.biciesto(año)){
            System.out.println(año + " es un año biciesto!");

        }else{
                        System.out.println(año + " no es un año biciesto!");

        }
        
        
    }
    
}
