/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package añobisiesto;

/**
 *
 * @author fruggiero
 */
public class logica {
    int año;
    String esBiciesto = "Es biciesto";
    String noEsBiciesto = "No es biciesto";


    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }
    
    public boolean biciesto(int año){
        if(this.año % 4 == 0 && año % 400 == 0){
            return true;
        }else if(this.año % 100 == 0 ){
            return false;
        }else{
            return false;
        }
    };

    @Override
    public String toString() {
        return "logica{" + "a\u00f1o=" + año + '}';
    }
    
    
}
