/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arrays.practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class secuency {

    private int num;
    int rounds = 5;
    double [] arr  = new double [rounds]; //Vector
    ArrayList <Integer> arrlist = new ArrayList<Integer>();
    int sum = 0;
    int prom = 0;
    double max = 0;
    Integer promList = 0;
    Integer sumList = 0;
    Integer maxList = 0;
    
    public void printArray(){
        Scanner entry = new Scanner(System.in);
        
        for (int i = 0; i < rounds; i++) {
        System.out.println("Agregá un número entero");
        
        num = entry.nextInt();
            arr[i] = num;
            arrlist.add(num);
        }
        System.out.println("El contenido del array es : " + Arrays.toString(arr));
        System.out.println("El contenido del arrayList es : " + arrlist.toString());
    }
    
    public void sumArray(){
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        System.out.println("La suma del array es : " + sum);
    }
    public void sumArrayList(){
        for (Integer var: arrlist) {
            sumList += var;
        }
        System.out.println("La suma del arrayList es : " + sumList);
    }
    
    public void promedy(){
        for (int i = 0; i < arr.length; i++) {
            prom += arr[i];
        }
        prom = prom / arr.length;
        System.out.println("El promedio es de : " + prom);
    }
//    public void promedyList(){
//        for (int i = 0; i < arr.length; i++) {
//            prom += arr[i];
//        }
//        prom = prom / arr.length;
//        System.out.println("El promedio es de : " + prom);
//    }
    
    public void maxArray(){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] > max){
                max = arr[i];
            }
        }
        System.out.println("El maximo valor guardado es : " + max);
    }
    public void maxArrayIterator(){
        
        Iterator it = arrlist.iterator();
        
        while(it.hasNext()){
            Integer currentValue = (Integer) it.next();

            if(currentValue > maxList){
                maxList = currentValue;
            }
        }
        System.out.println("El maximo valor guardado es : " + maxList);
    }
    
    
    
}
