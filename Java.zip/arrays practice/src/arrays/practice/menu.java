/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arrays.practice;

/**
 *
 * @author fruggiero
 */
public class menu {
    public void useMenu(){
        secuency a = new secuency();
        a.printArray();
        System.out.println("----------------------------- ");
        a.sumArray();
        System.out.println("----------------------------- ");
        a.sumArrayList();
        System.out.println("----------------------------- ");
        a.promedy();
        System.out.println("----------------------------- ");
        a.maxArray();
        System.out.println("----------------------------- ");
        a.maxArrayIterator();
}
}
