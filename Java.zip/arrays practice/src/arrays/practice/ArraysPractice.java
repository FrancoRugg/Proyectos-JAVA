/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arrays.practice;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ArraysPractice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        menu m = new menu();
        
        m.useMenu();
        
        
        
        
        
                
        
        
        
    }
    
}
