/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package francoruggiero300;

import java.time.DayOfWeek;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class DiaDeLaSemana {
    public void day(){
       Scanner entry = new Scanner(System.in);
        System.out.print("Ingrese un número del 1 al 7 (1=Domingo, 7=Sábado): ");
        int numeroDia = entry.nextInt();

        if (numeroDia < 1 || numeroDia > 7) {
            System.out.println("Número fuera de rango.");
        } else {
            String nombreDia = obtenerNombreDia(numeroDia);
            System.out.println("Día de la semana correspondiente: " + nombreDia);
        }
    }
    public static String obtenerNombreDia(int numeroDia) {
        switch (numeroDia) {
            case 1:
                return "Lunes";
            case 2:
                return "Martes";
            case 3:
                return "Miércoles";
            case 4:
                return "Jueves";
            case 5:
                return "Viernes";
            case 6:
                return "Sábado";
            case 7:
                return "Domingo";
            default:
                return "Desconocido";
        }
    }
}
