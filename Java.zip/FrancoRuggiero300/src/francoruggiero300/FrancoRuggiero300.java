/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package francoruggiero300;

/**
 *
 * @author fruggiero
 */
public class FrancoRuggiero300 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Ejercicio 301
        int n = 10; // Para cambiar el valor de n 

        try {
            long factorialIterativo = CaluladoraFactorial.calcularFactorialIterativo(n);
            long factorialRecursivo = CaluladoraFactorial.calcularFactorialRecursivo(n);

            System.out.println("Factorial de " + n + " (Iterativo): " + factorialIterativo);
            System.out.println("Factorial de " + n + " (Recursivo): " + factorialRecursivo);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
        //Ejercicio 302
        DiasParaCumple day = new DiasParaCumple();
        day.getDays();
        //Ejercicio 303
        DiaDeLaSemana d = new DiaDeLaSemana();
        d.day();
        //Ejercicio 304
        Circulo circulo = new Circulo(5.0);
        Triangulo triangulo = new Triangulo(4.0, 3.0, 3.0, 4.0, 5.0);

        System.out.println("Área del círculo: " + circulo.calcularArea());
        System.out.println("Perímetro del círculo: " + circulo.calcularPerimetro());

        System.out.println("Área del triángulo: " + triangulo.calcularArea());
        System.out.println("Perímetro del triángulo: " + triangulo.calcularPerimetro());
        
    }
    
    
    
}
