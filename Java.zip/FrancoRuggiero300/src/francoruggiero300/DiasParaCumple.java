/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package francoruggiero300;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class DiasParaCumple {
    Scanner entry = new Scanner(System.in);
    private String fechaAños;
    public void getDays(){
        System.out.println("Ingrese la fecha de su próximo cumpleaños en formato \"yyyy-MM-dd\"");
//        String fechaCumpleanios = "2023-11-07";
        fechaAños = entry.nextLine();
          // Ingrese la fecha de su próximo cumpleaños en formato "yyyy-MM-dd"
//        String fechaCumpleanios = "2023-11-07";

        LocalDate fechaCumple = LocalDate.parse(fechaAños, DateTimeFormatter.ISO_LOCAL_DATE);
        LocalDate fechaActual = LocalDate.now();
        LocalDate fechaProximoCumple = fechaCumple.withYear(fechaActual.getYear());

        if (fechaProximoCumple.isBefore(fechaActual) || fechaProximoCumple.isEqual(fechaActual)) {
            fechaProximoCumple = fechaCumple.withYear(fechaActual.getYear() + 1);
        }

        long diasRestantes = ChronoUnit.DAYS.between(fechaActual, fechaProximoCumple);

        System.out.println("Días restantes hasta su próximo cumpleaños: " + diasRestantes);
    
    }
}
