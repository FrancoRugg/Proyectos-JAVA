/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package numeroaleatorio1a10;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class juego {
    
    int aleatorio;
    int intentos;

    public juego() {
        this.intentos = 3;
    }
    
    public void menu() {
        
        int numero;
        this.genera_aleatorio();
        System.out.println(this.aleatorio);
        
        Scanner menu1 = new Scanner(System.in);
        
//        while (contador < this.intentos){
//            int contador = 0;
//            numero= menu1.nextInt();
//            
//            
//            contador += 1;
//            System.out.println("El numero es " + this.aleatorio);
//
//        }
        for (int i = 0; i < this.intentos; i++) {
            
//            Pedir números
              System.out.println("Tiene tres intentso, Adivina un numero del 1 al 10 :");
              numero = menu1.nextInt();
              
//            Cancular Intentos
              boolean resultado = this.calcula_intento(numero);
              
              if(resultado == true){
                System.out.println("Verdadero!");
                 break;

              }else{
                System.out.println("Intente de nuevo...");

              }
              
        }
        
    }
//            Informar Resultados
    public boolean calcula_intento(int intento) {
        
        if(intento == this.aleatorio){
            return true;
        }else{
            return false;
        }
        
    }
    public void genera_aleatorio() {
        
        this.aleatorio = (int)(Math.random()*10+1);
        
    }
    
    
    
    
    
}
