/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package d10;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class D10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entry = new Scanner(System.in);
        System.out.println("ingresá un texto de dos palabras : ");
        
        String word = entry.nextLine();
        
        System.out.println("Ingresá una palabra : ");
        
        String midWord = entry.nextLine();
        
        System.out.println("Solution 1 : " + word);
        int space = word.indexOf(" ");
        String s1 = word.substring(0 , space);
        String s2 = word.substring(space); // es lo mismo que es s4
        String s4 = word.substring(space, word.length()); // es lo mismo que es s2
        
        String fatal = s1 + " " + midWord + s2;
        
        System.out.println("Palabras : " + fatal);
        
        
    }
    
}
