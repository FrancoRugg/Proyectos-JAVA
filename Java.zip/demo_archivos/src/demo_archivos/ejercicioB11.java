/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo_archivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author fruggiero
 */
public class ejercicioB11 {
    ArrayList<String> bdd = new ArrayList<>();
    public void read(){
        String nombre_archivo = "c:/temporal/datos.txt";
//        String nombre_archivo = "c:\\temporal\\notas.txt";

        try {
            FileReader fr = new FileReader(nombre_archivo);
            BufferedReader br = new BufferedReader(fr);
            
            String line;
            while ((line = br.readLine()) != null ) {
                int large = line.length();
                System.out.println(large + " - " + line);
            }
            
        } catch (FileNotFoundException e) {
//            System.out.println(e);
            e.printStackTrace();
        } catch (IOException e) {
//            System.out.println(e);
            e.printStackTrace();
        }
        
    }
    public void readAlumnos(){
        String nombre_archivo = "c:/temporal/base_alumnos.txt";
//        String nombre_archivo = "c:\\temporal\\notas.txt";

        try {
            FileReader fr = new FileReader(nombre_archivo);
            BufferedReader br = new BufferedReader(fr);
            String line;
            while ((line = br.readLine()) != null ) {
//                int large = line.length();
//                System.out.println(large + " - " + line);
                  bdd.add(line);
            }
            
        } catch (FileNotFoundException e) {
//            System.out.println(e);
            e.printStackTrace();
        } catch (IOException e) {
//            System.out.println(e);
            e.printStackTrace();
        }
        
    }
    public void printBdd(){
        for (int i = 0; i < bdd.size(); i++) {
            String get = bdd.get(i);
            String [] separate = get.split(",");
            long dni = Long.parseLong(separate[1].trim());
            if(dni < 45000000){
                System.out.println(separate[0]);
            }
        }
    }
}
