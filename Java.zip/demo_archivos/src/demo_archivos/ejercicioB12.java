/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo_archivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author fruggiero
 */
public class ejercicioB12 {
    public void readLines(){
        String nombre_archivo = "c:/temporal/salida.txt";
//        String nombre_archivo = "c:\\temporal\\notas.txt";

//En el caso de que no exista el archivo en las carpetas, lo crea;
        try {
            PrintWriter pr = new PrintWriter(nombre_archivo);
            for (int i = 0; i < 10; i++) {
                String linea = "Linea " + i;
                pr.println(linea);
                System.out.println(linea);
            }
            pr.close();
        } catch (FileNotFoundException e) {
//            System.out.println(e);
            e.printStackTrace();
        } catch (IOException e) {
//            System.out.println(e);
            e.printStackTrace();
        }
        
    }
    
}
