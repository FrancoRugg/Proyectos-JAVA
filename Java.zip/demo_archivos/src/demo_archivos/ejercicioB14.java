/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo_archivos;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicioB14 {
    Scanner entry = new Scanner(System.in);
    ArrayList<String> arr = new ArrayList<>();
    private String add;
    private String nombre_archivo = "c:/temporal/guardar.txt";
    private int bytes = 0;
    //Crea un archivo con los datos agregados por el Scanner en la ruta de la carpeta
    //A su vez al final de cada guardado, te muestra la cantidad de Bytes subidos
    
    public void writeMemory(){
        do {           
            System.out.println("Ingresá un texto : ");
            add = entry.nextLine();
            
            if(!add.equals("*"))
            arr.add(add);
            
        } while (!add.equals("*"));
    }
    public void saveMemory(){
        try {
            PrintWriter pr = new PrintWriter(new FileWriter(nombre_archivo, true));
            for (int i = 0; i < arr.size(); i++) {
                String linea = arr.get(i);
                pr.println(linea);
                bytes += linea.length();
                System.out.println(linea);
            }
            pr.close();
            System.out.println("Bytes escritos: " + bytes);
        } catch (FileNotFoundException e) {
//            System.out.println(e);
            e.printStackTrace();
        } catch (IOException e) {
//            System.out.println(e);
            e.printStackTrace();
        }
    }
}
