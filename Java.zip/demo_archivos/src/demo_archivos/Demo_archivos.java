/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package demo_archivos;

/**
 *
 * @author fruggiero
 */
public class Demo_archivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        ejercicioB11 b11 = new ejercicioB11();
//        b11.read();
//        b11.readAlumnos();
//        b11.printBdd();
//        ejercicioB12 b12 = new ejercicioB12();
//        b12.readLines();
        ejercicioB14 b14 = new ejercicioB14();
        b14.writeMemory();
        b14.saveMemory();
    }
    
}
