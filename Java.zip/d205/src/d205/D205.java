/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package d205;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class D205 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
                Scanner entry    = new Scanner(System.in);
//                System.out.println("Ingreasr texto :");
//                String naza = entry.nextLine();
//                
//                System.out.println("El texto ingresado tiene un largo de " + naza.length());
//                System.out.println("El texto ingresado contiene num 5?  " + naza.contains("5"));
//                System.out.println("El texto ingresado empieza con un espacio ?  " + naza.startsWith(" ") + " y El texto ingresado termina con un espacio " + naza.endsWith(" "));
//                System.out.println("Reemplazando A por $: " + naza.replace("a", "$"));
//                System.out.println("Sacando el espacio entre nosotros: " + naza.trim());
//                System.out.println("El primer 5 se encuentra en la posición : " + naza.indexOf("5"));

                System.out.println("Ingresar num telefonico de 10 nums: ");
                String gasti = entry.nextLine();
                
                String p1 = gasti.substring(0,2);
                String p2 = gasti.substring(2,3);
                String p3 = gasti.substring(3);
                
                String gastiResult = "("+ p1 + ")" + "-" + p2 + "-" + p3;
                
               System.out.println(gastiResult);
                StringBuffer gasti2 = new StringBuffer("(");
                
                gasti2.append(p1 + ")" + "-" + p2 + "-" + p3);
//                gasti2.append(p1 + ")").append("-").append(p2).append("-" + p3);
               System.out.println(gasti2);
                       
                
 
      

   
                
                
    }   

   
}
