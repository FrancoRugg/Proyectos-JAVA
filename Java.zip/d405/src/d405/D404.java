/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package d405;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class D404 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entry = new Scanner(System.in);
            System.out.println("Ingresá un num: ");
            int num = entry.nextInt();
            System.out.println("Ingresá un num: ");
            int num2 = entry.nextInt();
            ArrayList<String> moltiplo = new ArrayList<String>();
            ArrayList<String> noEsMultiplo = new ArrayList<String>();

        for (int i = num; i <= num2; i++) {

            if ((num - num2) >= 30 || (num2 - num) >= 30) {
                if ((i % 7)  == 0) {
                    moltiplo.add ("num:" + i);
                } else {
                    noEsMultiplo.add("num: " + i);                
                }
            
            }else {
                System.out.println("El intervalo entre ambos no es mayor o igual a 30");
                break;
            }
        }
            Iterator <String> nombreIterator = moltiplo.iterator();
            boolean estaVacio = moltiplo.isEmpty();
            if(!estaVacio){
                System.out.println("El intervalo entre ambos es mayor o igual a 30");
                System.out.println("los numeros siguientes numeros son multiplos de 7");
                while(nombreIterator.hasNext()){
                    String elemento = nombreIterator.next();
                    System.out.print(elemento+" / ");
                }
            }
            System.out.println("");
            System.out.println("------------------------------------");            
            Iterator <String> nombreIterator2 = noEsMultiplo.iterator();
            boolean estaVacio2 = noEsMultiplo.isEmpty();
            if(!estaVacio2){
            System.out.println("Los siguientes numeros no son multiplo de 7");
            while(nombreIterator2.hasNext()){
                String elemento2 = nombreIterator2.next();
                System.out.println( elemento2 + " / ");
            }
            }


    }
}
