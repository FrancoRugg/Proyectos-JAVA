/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_300_francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class _304_ {
    public void solution(){
    Scanner entry = new Scanner(System.in);
    
        System.out.println("Ingresa una frase :");
        
        String frase = entry.nextLine();
        int cant_vocales = 0;
        int cant_no_vocales = 0;
//        System.out.println("La frase tiene " + frase.length() + " caracteres");
        for (int i = 0; i < frase.length(); i++) {
            String string_letter = "";
            char letter = frase.charAt(i);
            string_letter += letter;
            if(string_letter.contains("a")||string_letter.contains("e")||string_letter.contains("i")|| string_letter.contains("o")||string_letter.contains("u")){
               cant_vocales += 1;
               string_letter = "";
            }else{
                cant_no_vocales += 1;
                string_letter = "";
            }
            
        }
            System.out.println("La frase es : " + frase);
            System.out.println("----------------------");
            System.out.println("La cantidad de vocales en la frase son : " + cant_vocales);
            System.out.println("La cantidad de no vocales en la frase son : " + cant_no_vocales);
    }
}
