/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_300_francoruggiero;

/**
 *
 * @author fruggiero
 */
public class Ejercicios_300_FrancoRuggiero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("-------------------");
        _301_ one = new _301_();
        one.solution();
        System.out.println("-------------------");
        _302_ two = new _302_();
        two.solution();
        System.out.println("-------------------");
        _303_ three = new _303_();
          three.solution();
        System.out.println("-------------------");
        _304_ four = new _304_();
        four.solution();
        System.out.println("-------------------");
        _305_ five = new _305_();
        five.solution();
        System.out.println("-------------------");
        _306_ six = new _306_();
        six.solution();
    }
    
}
