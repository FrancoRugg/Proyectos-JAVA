/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_300_francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class _305_ {

    public void solution() {
        Scanner entry = new Scanner(System.in);

        System.out.println("Ingresa una oracion :");

        String frase = entry.nextLine();

        System.out.println("La frase tiene " + frase.length() + " caracteres");
        
        String[] words = frase.split(" ");
        int count = words.length;
        
        if(!frase.startsWith(" ") && !frase.contains("  ") && !frase.endsWith(" ")){
            if(frase.endsWith(" ")){
            count = words.length - 1;
        }
            System.out.println("El texto tiene " + words.length +" palabras ");
        for(String word: words){
            System.out.println(word);
        }
        }else{
            System.out.println("No se puede ingresar espacios al principio, al final o dos espacios seguidos!");
        }
        
        //Esta misma es la primera forma en la que pensé realizar el ejercicio en un principio, cuando me dí cuenta que no se
//        podía leí en el material y continué el ejercicio con la ayuda del Split().
//        int countWords = 0;
//        String string_word = "";
//        for (int i = 0; i < frase.length(); i++) {
////            char first_position = frase.charAt(0) == " ";
//            char word = frase.charAt(i);
//            string_word += word;
//            
//            if(string_word.contains("  ") ||  string_word.startsWith(" ") || string_word.endsWith(" ")){
//                System.out.println("No puede ingresar dos espacios seguidos, tampoco ingresar un espacio al principio o al final!");
//                break;
//            }
//            if(string_word.contains(" ") || !string_word.endsWith(" ")){
//                    countWords += 1;
//                }
//            
//        }
//        System.out.println("La palabra contiene " + countWords + " palabras");
    }
}
