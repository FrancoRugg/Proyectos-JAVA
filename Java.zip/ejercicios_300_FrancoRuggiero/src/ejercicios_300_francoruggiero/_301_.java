/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_300_francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class _301_ {
    
    public void solution(){
    Scanner entry = new Scanner(System.in);
    
        System.out.println("Ingresa una frase :");
        
        String frase = entry.nextLine();
        
        System.out.println("La frase tiene " + frase.length() + " caracteres");
    }
    
}
