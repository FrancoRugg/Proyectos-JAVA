/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_300_francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class _306_ {
    public void solution(){
    Scanner entry = new Scanner(System.in);
    
        System.out.println("Ingresa una frase :");
        
        String frase = entry.nextLine();
        
        System.out.println("Ingresa otra frase :");
        
        String frase2 = entry.nextLine();
        
        //Se me ocurrió hacer estas dos opciones:
        
        //En esta misma te compara si el primer campo contiene exactamente lo del segundo campo.
//        if(frase.equals(frase2)){
//            System.out.println(" El segundo campo se encuentra incluido dentro del primero - metodo equals - ");
//        }else{
//            System.out.println(" ¡¡El segundo campo no se encuentra dentro del primero!! - metodo equals - ");
//        }

//          De ser necesario, puede probar ambas. Dejé una comentada para que no se mezple con la otra.

        //En este otro, en cambio, te figura si dentro del primer campo contiene el segundo campo.
        if(frase.contains(frase2)){
            System.out.println(" El segundo campo se encuentra incluido dentro del primero - metodo contains - ");
        }else{
            System.out.println(" ¡¡El segundo campo no se encuentra dentro del primero!! - metodo contains - ");
        }
    }
}
