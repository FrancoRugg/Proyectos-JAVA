/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_300_francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class _303_ {
    public void solution(){
    Scanner entry = new Scanner(System.in);
    
        System.out.println("Ingresa una frase :");
        System.out.println("Agregué que la frase tenga que ser par en base a lo que le consulté.");
        String frase = entry.nextLine();
        
        System.out.println("La frase tiene " + frase.length() + " caracteres");
        System.out.println("-------------------------");
        System.out.println("Frese ingresada: " + frase);
        int result_half_frase = frase.length() / 2 ;
       String first = "";
       String second = "";
        if(frase.length() % 2 == 0){
            for (int i = 0; i < result_half_frase; i++) {
                char first_half = frase.charAt(i);
                first += first_half;
            }
            for (int i = result_half_frase; i < frase.length(); i++) {
                char second_half = frase.charAt(i);
                second += second_half;
            }
                System.out.println("Primera mitad : " + first);
                System.out.println("Segunda mitad: " + second);
        }else{
            System.out.println("Frase incorrecta! Ingrese una frase que sea par...");
        }
    }
}
