/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

/**
 *
 * @author fruggiero
 */
public class allExercises {
//    ejercicio_101 oneE = new ejercicio_101();
//    
//    oneE.nativeArray();
//    oneE.see
}
