/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicio_103 {
    
    
    ArrayList<Integer> arr = new ArrayList<>();
    Integer sum = 0;
    Integer size = 10;
    Integer promedy;
    Integer lower = 0;
    Integer equal = 0;
    Integer top = 0;
    
    
    public void newArrayList(){
        Scanner entry = new Scanner(System.in);

        
        for (int i = 0; i < size; i++) {
            System.out.println("Ingresa un numero:");   
            int num = entry.nextInt();
            
            arr.add(num);
            sum += num;
        }
        promedy = (sum /size);
        System.out.println("ArrayList COMPLETADO,");
        System.out.println("El ArrayList tiene un promedio de " + promedy);
    }
    
    public void arrayListValues(){
        for (int i = 0; i < arr.size(); i++) {
           Integer result = arr.get(i);
            
           if(result > promedy){
               top +=1;
           }
           else if(result < promedy){
               lower +=1;
           }
           else{
               equal +=1;
           }
        }
        System.out.println("Dentro del promedio del ArrayList : ");
        
        System.out.println("Se encuentran " + lower + " valores por debajo del promedio");
        System.out.println("Se encuentran " + equal + " valores iguales al promedio");
        System.out.println("Se encuentran " + top + " valores por encima del promedio");
        
    }
            
}
