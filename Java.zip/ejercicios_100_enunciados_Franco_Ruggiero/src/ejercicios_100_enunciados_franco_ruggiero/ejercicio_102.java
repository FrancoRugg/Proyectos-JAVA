/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicio_102 {
 
    ArrayList<Integer> arr = new ArrayList<>();
    Integer sum = 0;
    
    public void numberArrayList(){
        Scanner entry = new Scanner(System.in);

        System.out.println("De que tamaño quiere que sea el ArrayList: indicarlo en numeros");
        int large = entry.nextInt();
        
        for (int i = 0; i < large; i++) {
            int random = (int) (Math.random() * 9);
            
            arr.add(random);
        }
        
        System.out.println("ArrayList COMPLETADO,");
    }    
    
    public void seeArrayList(){
        for (int i = 0; i < arr.size(); i++) {
            System.out.println("En el indice " + i + ", se encuentra el valor " + arr.get(i) );
        }
    }
    
    public void sumArrayList(){
        for (Integer i : arr) {
            sum += i;
        }
        System.out.println("La suma del arrayList da un valor de " + sum);
    }
}
