/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicio_104 {
    
    ArrayList<Integer> arr = new ArrayList<>();
    Integer size = 7;
    Integer promedy;
    Integer min = 0;
    Integer max = 0;
    
    
    public void sevenArrayList(){
        Scanner entry = new Scanner(System.in);

        for (int i = 0; i < size; i++) {
            System.out.println("Ingresa un numero:");   
            int num = entry.nextInt();
            
            arr.add(num);
        }
        System.out.println("Seven positions ArrayList COMPLETE");
    }
    
    public void maxValues(){
            max = arr.get(0);
        for (int i = 0; i < arr.size(); i++) {
           Integer single = arr.get(i);

           if(single > max){
               max = single;
           }
           
        }
        
        System.out.println("El valor mayor es " + max );
        
    }
    public void minValues(){
            min = arr.get(0);
        for (int i = 0; i < arr.size(); i++) {
           Integer single = arr.get(i);
           if(single < min){
               min = single;
           }
           
        }
        
        System.out.println("El valor menor es " + min );
        
    }
    public void arrayListPositions(){
        for (int i = 0; i < arr.size(); i++) {
           Integer value = arr.get(i);
            
        System.out.println("En la posicion " + i + ", se encuentra el valor " + value );
           
        }
        
    }
    
}
