/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.ArrayList;

/**
 *
 * @author fruggiero
 */
public class ejercicio_105 {
    
    
    ArrayList<Integer> arr =new ArrayList<>();
    ArrayList<Integer> arr2 =new ArrayList<>();
    ArrayList<Integer> arr3 =new ArrayList<>();
    
    public void array(){
        
        
//        Preguntar este ejercicio
        
        for(int i = 0; i < 100; i++ ){
        Integer random = (int) (Math.random() * 100);
            arr.add(random);
//            System.out.println("Random 1 : " + random);
        }
        for(int i = 0; i < 100; i++ ){
        Integer random = (int) (Math.random() * 100);
            arr2.add(random);
//            System.out.println("Random 2 : " + random);
        }
        
        
    }
    
    
    public void repeat(){
        for (int i = 0; i < arr.size(); i++) {
            Integer get = arr.get(i);
                for (int e = 0; e < arr2.size(); e++) {
                    Integer get2 = arr2.get(e);
                    if(get == get2){
//                    System.out.println("Elemento repetido : " + get);
                        if(arr3.contains(get)){
                            
                        }else{
                            arr3.add(get);
                        }
                        break;
                    }
                    
                }
        }
        for (int i = 0; i < arr3.size(); i++) {
            System.out.println("Repetido : " + arr3.get(i));
        }
    }
        
        
}
