/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicio_108 {
    ArrayList<String> arr = new ArrayList<>();
    Scanner entry = new Scanner(System.in);

       public void frase(){
           System.out.println("Ingrese palabras (escriba '*' para finalizar):");

        while (true) {
            String word = entry.nextLine();

            if (word.equals("*")) {
                break; // Salir del bucle cuando se ingrese '*'
            }

            if (!arr.contains(word)) {
                arr.add(word); // Agregar la entrada si no está en la lista
            } else {
                System.out.println("Elemento repetido, ingrese otro.");
            }
        }
       }
       public void showFrase(){
           System.out.println("Frases del array : ");
           for(String e: arr){
               System.out.println(e);
           }
       }
}
