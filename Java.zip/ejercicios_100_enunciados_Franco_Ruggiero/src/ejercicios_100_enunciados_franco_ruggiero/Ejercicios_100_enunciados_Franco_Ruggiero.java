/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

/**
 *
 * @author fruggiero
 */
public class Ejercicios_100_enunciados_Franco_Ruggiero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ejercicio_101 one = new ejercicio_101();
    
        one.nativeArray();
        System.out.println("--------------------------------------");
        one.seeNativeArray();
        System.out.println("--------------------------------------");
        
        
        ejercicio_102 two = new ejercicio_102();
        
        two.numberArrayList();
        System.out.println("--------------------------------------");
        two.seeArrayList();
        System.out.println("--------------------------------------");
        two.sumArrayList();
        System.out.println("--------------------------------------");
        
        ejercicio_103 three = new ejercicio_103();

        three.newArrayList();
        three.arrayListValues();
        System.out.println("--------------------------------------");
        ejercicio_104 four = new ejercicio_104();

        four.sevenArrayList();
        System.out.println("--------------------------------------");
        four.maxValues();
        four.minValues();
        four.arrayListPositions();
        System.out.println("--------------------------------------");
        ejercicio_105 five = new ejercicio_105();
        five.array();
        five.repeat();        
        System.out.println("--------------------------------------");
        ejercicio_106 six = new ejercicio_106();
        six.frase();
        six.recorrerArray();
        System.out.println("--------------------------------------");
        ejercicio_107 seven = new ejercicio_107();
        seven.frase();
        seven.recorrerArray();
        System.out.println("La diferencia entre salidas vendría a ser que en el hashset viene la respuesta encriptada!");
        System.out.println("--------------------------------------");
        ejercicio_108 eigth = new ejercicio_108();
        
        eigth.frase();
        eigth.showFrase();
    }
    
}
