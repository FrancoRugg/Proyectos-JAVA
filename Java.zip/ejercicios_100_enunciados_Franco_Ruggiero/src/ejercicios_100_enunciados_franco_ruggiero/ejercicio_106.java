/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicio_106 {
    Scanner entry = new Scanner(System.in);
    ArrayList <String> separados = new ArrayList<>();

    public void frase(){
        System.out.println("Ingresá una frase de texto compuesta por varias palabras : ");
        String words = entry.nextLine();
        
        String[] cadena = words.split(" ");
        if(cadena.length > 1){
            for (int i = 0; i < cadena.length; i++) {
                String only = cadena[i];
                separados.add(only);
            }
        }else{
            System.out.println("Error. Ingrese una frase compuesta por varias palabras.");
        }
    }
    
    public void recorrerArray(){
        System.out.println("--------------------");
        System.out.println("Cantidad de palabras ingresadas : " + separados.size());
        System.out.println("--------------------");
        for (int i = 0; i < separados.size(); i++) {
            System.out.println("En el indice " + i + ", se encuentra el valor " + separados.get(i));
            System.out.println(separados.get(i).hashCode());
        }
    }
}
