/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios_100_enunciados_franco_ruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class ejercicio_101 {
    int rounds = 5;
    double [] arr = new double [rounds];

    
    public void nativeArray(){
        Scanner entry = new Scanner(System.in);
        
        for (int i = 0; i < rounds; i++) {
            System.out.println("Ingresá un n°: ");
            int num = entry.nextInt();
            
            arr[i] = num;
            
        }
        
        System.out.println("Array nativo completado.");
    }
    
    public void seeNativeArray(){
        for (int i = 0; i < rounds; i++) {
            System.out.println("En el indice " + i + ", se encuentra el valor " + arr[i]);
        }
    }
    
}
