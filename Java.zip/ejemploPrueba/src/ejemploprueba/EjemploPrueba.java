/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemploprueba;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class EjemploPrueba {

    /**
     * @param args the command line arguments
     */
    public static void mostrarCorredores( int[]vector_runners ){
        for (int i = 0; i < vector_runners.length; i++) {
            System.out.println("Corredor "+ (i + 1) + " :" + vector_runners[i]);
        }
    }
    
    public static void primerLugar(int[]vector_runners){
        int winner = 0;
        int winner_time = vector_runners[0];
        for (int i = 0; i < vector_runners.length; i++) {
            if(vector_runners[i] < winner_time){
            winner = i + 1;
            winner_time = vector_runners[i];
            }
            
        }
            System.out.println("Primer lugar en del corredor : " + winner + " Con el tiempo de : " + winner_time);
    }
    
    public static void promedios(int[]vector_runners){
        int suma_tiempos = 0;
        int resto_participantes = 0;

        for (int i = 0; i < vector_runners.length; i++) {
            suma_tiempos += vector_runners[i]; 
        }
        
        int cuenta_promedio = suma_tiempos / (vector_runners.length + 1);
        for (int j = 0; j < vector_runners.length; j++) {
            if(vector_runners[j] < cuenta_promedio){
                resto_participantes += 1;
            }
        }
        
            System.out.println("El promedio es :" + cuenta_promedio);
            System.out.println("Participantes con el tiempo menor al promedio : " + resto_participantes);


    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entry = new Scanner(System.in);
        
        System.out.println("Ingresa la cantidad de corredores : ");
        
        int runners = entry.nextInt();
        
        int vector_runners [] = new int [runners];
        
        for (int i = 0; i < vector_runners.length; i++) {
            System.out.println("Ingrese el tiempo del corredor " + (i + 1) + " :");
            vector_runners[i] = entry.nextInt();
        }
        
        mostrarCorredores(vector_runners);
        primerLugar(vector_runners);
        promedios(vector_runners);
    }
    
    
}
