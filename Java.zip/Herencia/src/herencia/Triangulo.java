/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author fruggiero
 */
public class Triangulo extends Figura{
    private int lado2;
    private int lado3;

    public Triangulo(int base, int altura, int lado2, int lado3) {
        super(base, altura);
        this.lado2 = lado2;
        this.lado3 = lado3;
    }
    @Override
    public int perimetro(){
        return base + lado2 + lado3;
    }
    @Override
    public float area(){
        return (base * altura) / 2;
    }
    
    public String tipo(){
        if(lado2 == lado3 && base == lado3){
            return "Equilatero";
        }else if(base != lado2 && base != lado3 && lado2 != lado3){
            return "Escaleno";
        }else{
            return "Isosceles";
        }
    }
    @Override
    public String toString() {
        return "Figura{" + "base=" + base + ", altura=" + altura + ", el area es: " + area() + ", el perimetro es: " + perimetro() + ", es un triangulo : " + tipo()+ '}';
    }

}
