/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package herencia;

/**
 *
 * @author fruggiero
 */
public class Herencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("--------------------");
        System.out.println("Cuadrado :");
        Cuadrado cuad = new Cuadrado(2, 2);
            System.out.println(cuad.toString());
        System.out.println();
        System.out.println("Triangulo :");
        Triangulo Tri = new Triangulo(7, 3, 4, 4);
            System.out.println(Tri.toString());
        System.out.println();
        System.out.println("Trapecio :");
        Trapecio tra = new Trapecio(7, 3, 4, 4);
        System.out.println(tra.toString());
    }
}
