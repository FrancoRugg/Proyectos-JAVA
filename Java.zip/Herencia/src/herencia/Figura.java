/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author fruggiero
 */
public abstract class Figura {
    protected int base;
    protected int altura;

    public Figura(int base, int altura) {
        this.base = base;
        this.altura = altura;
    }
    
    public abstract int perimetro();
    
    public abstract float area();

    @Override
    public String toString() {
        return super.toString();
    }
    
    
}
