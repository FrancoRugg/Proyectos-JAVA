/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author fruggiero
 */
public class Trapecio extends Figura{
    private int techo;
    private int lado;

    public Trapecio(int base, int altura, int techo, int lado) {
        super(base, altura);
        this.techo = techo;
        this.lado = lado;
    }
    
    
    @Override
    public float area(){
        return (((float)(base + techo)/2)* altura);
    }
    @Override
    public int perimetro(){
        return (base + techo + lado * 2);
    }
    
    @Override
    public String toString() {
        return "Figura{" + "base=" + base + ", altura=" + altura + ", techo=" + techo + ", lado=" + lado + ", el area es: " + area() + ", el perimetro es: " + perimetro() + '}';
    }
    
}
