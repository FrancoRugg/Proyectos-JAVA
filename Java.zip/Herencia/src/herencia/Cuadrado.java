/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author fruggiero
 */
public class Cuadrado extends Figura{

    
    public Cuadrado(int base, int altura) {
        super(base, altura);
    }
    @Override
    public float area(){
        return base * altura;
    }
    @Override
    public int perimetro(){
        return ((base * 2) + (altura * 2));
    }
    
    public boolean esCuadrado(){
        return (base == altura);
    }
    @Override 
    public String toString() {
        return "Figura{" + "base=" + base + ", altura=" + altura + ", el area es: " + area() + ", el perimetro es: " + perimetro() + (esCuadrado() ? ", Es un Cuadrado" : ", No es un Cuadrado") + '}';
    }
    
}
