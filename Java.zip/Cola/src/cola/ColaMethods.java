/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cola;

/**
 *
 * @author fruggiero
 */
public class ColaMethods<Type> {
    private Nodo<Type> first;
    private Nodo<Type> last;
    private int size;

    public ColaMethods() {
        this.first = null;
        this.last = null;
        this.size = 0;
    }
    
    
    public boolean isEmpty(){
        return size == 0;
    }
    
    public int size(){
        return this.size;
    }
    
    public void agregar(Type element){
        Nodo aux = new Nodo(element, null);
        if(isEmpty()){
            first = aux;
            last = aux;
        }else{
            this.last.setNext(aux);
            this.last = aux;
        }
        size ++;
    }
    
    public Type sacar(){
        if(isEmpty()){
            return null;
        }else{
            Type result =  first.getElement();
            first = first.getNext();
            size --;
            return result;
        }
    }
    
    public Type primero(){
        if(isEmpty()){
            return null;
        }else{
            Type res = first.getElement();
            return res;
        }
    }

    @Override
    public String toString() {
        if(!isEmpty()){
            String res = "";
            Nodo aux = first;

            while (aux != null) {
                res += aux.getElement().toString() + "\n";
                aux = aux.getNext();
            }
            return res;
        }else{
            return "Cola vacia.";
        }
    }
}
