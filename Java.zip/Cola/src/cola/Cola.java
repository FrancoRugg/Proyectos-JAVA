/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cola;

/**
 *
 * @author fruggiero
 */
public class Cola{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ColaMethods<String> c = new ColaMethods<>();
            c.agregar("pepe");
            c.agregar("lola");
            c.agregar("ana");
            c.agregar("sulma");
            c.agregar("pantera");
            c.agregar("rasconagian");
            
            System.out.println(c.toString());
            System.out.println(c.primero());
    }
    
}
