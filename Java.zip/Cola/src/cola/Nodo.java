/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cola;

/**
 *
 * @author fruggiero
 */
public class Nodo<Type> {
    private Type element;
    private Nodo next;

    public void setElement(Type element) {
        this.element = element;
    }

    public void setNext(Nodo next) {
        this.next = next;
    }
    
    public Nodo(Type element, Nodo next) {
        this.element = element;
        this.next = next;
    }

    public Type getElement() {
        return element;
    }
    

    public Nodo getNext() {
        return next;
    }    
    
}
