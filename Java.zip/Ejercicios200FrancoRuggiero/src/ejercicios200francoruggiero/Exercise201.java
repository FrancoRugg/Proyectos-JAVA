/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios200francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Exercise201{
    String elcuit;

    public String getElcuit() {
        return elcuit;
    }

    public void setElcuit(String elcuit) {
        this.elcuit = elcuit;
    }

    public boolean isValidCUIT() {
        if (getElcuit().length() != 11) {
            System.out.println("CUIT incorrecto");
            return false;
        }

        String cuit = getElcuit();

        // La secuencia de valores de factor es 5, 4, 3, 2, 7, 6, 5, 4, 3, 2
        int[] factor = {5, 4, 3, 2, 7, 6, 5, 4, 3, 2};

        int[] cifras = new int[11];

        

        int resultado = 0;

        for (int i = 0; i < 10; i++) {
            resultado += cifras[i] * factor[i];
        }

        int cifraControl = (11 - (resultado % 11)) % 11;

        if (cifraControl == cifras[10]) {
            return true;
        } else {
            return false;
        }
    }

    public String getCuitFormat() {
        String fcuit = getElcuit().substring(0, 2) + "-" + getElcuit().substring(2, 10) + "-" + getElcuit().substring(10);
        return fcuit;
    }
    
    public void test(){
        Scanner entry  = new Scanner(System.in);
        
        System.out.println("Agregue un cuit a validar: xx-xxxxxxxx-x");
        String valor = entry.nextLine();
        
        setElcuit(valor);
        System.out.println("Valido : " + isValidCUIT());
        System.out.println(getCuitFormat());
    }
    
    
}
