/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios200francoruggiero;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author fruggiero
 */
public class Exercise204 {
        private Scanner scanner = new Scanner(System.in);
        private ArrayList<String> palabras = new ArrayList<>();
        private Stack<String> pila = new Stack<>();

        public void palabras(){
            
        System.out.println("Ingresa palabras (termina con '*'):");

        while (true) {
            String palabra = scanner.nextLine();
            if (palabra.equals("*")) {
                break;
            }
            palabras.add(palabra);
        }

        // Agrega elementos del ArrayList a la pila
        for (String palabra : palabras) {
            pila.push(palabra);
        }

        System.out.println("Palabras en orden inverso al ingreso:");
        while (!pila.isEmpty()) {
            System.out.println(pila.pop());
        }
        // Paso c: El orden de impresión de salida es inverso al orden de entrada.

    }
}
