/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios200francoruggiero;

/**
 *
 * @author fruggiero
 */
public class Ejercicios200FrancoRuggiero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Exercise201 one = new Exercise201();
        one.test();
        
        System.out.println("-----------");
        
        Exercise202 two = new Exercise202();
        
        two.writeTxt();
        two.saveMemory();
        two.writeMemory();
        
        System.out.println("-----------");
        
        Exercise203 procesador = new Exercise203();
        
        procesador.ingresarDato(1);
        procesador.ingresarDato(2);
        procesador.ingresarDato(3);
        procesador.ingresarDato(4);
        procesador.ingresarDato(5);

        procesador.procesarEntrada();
        procesador.imprimirEntradaSalidas();
        
        System.out.println("-----------");

        Exercise204 four = new Exercise204();
        
        four.palabras();

        System.out.println("-----------");

        Exercise205 five = new Exercise205();
        
        five.five();
        
        
        System.out.println("-----------");

        Exercise206 six = new Exercise206();
        
        six.six();
    }
    
}
