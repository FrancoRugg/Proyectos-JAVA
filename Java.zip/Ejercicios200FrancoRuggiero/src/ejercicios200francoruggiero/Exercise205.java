/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios200francoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Exercise205 {
    private Scanner scanner = new Scanner(System.in);
    
    public void five(){

        System.out.println("Ingrese los siguientes datos:");
        String nombre = ingresarTexto("Nombre: ");
        if (nombre.equals("*")) {
            System.out.println("Saliendo del programa.");
            return;
        }
        int edad = ingresarNumero("Edad: ");
        if (edad == -1) {
            System.out.println("Edad ingresada en un formato incorrecto. Saliendo del programa.");
            return;
        }
        String domicilio = ingresarTexto("Domicilio (calle): ");
        if (domicilio.equals("*")) {
            System.out.println("Saliendo del programa.");
            return;
        }
        int altura = ingresarNumero("Altura: ");
        if (altura == -1) {
            System.out.println("Altura ingresada en un formato incorrecto. Saliendo del programa.");
            return;
        }

        System.out.println("\nDatos ingresados:");
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad);
        System.out.println("Domicilio: " + domicilio + " " + altura);

        scanner.close();
    }

    public static String ingresarTexto(String mensaje) {
        Scanner scanner = new Scanner(System.in);
        System.out.print(mensaje);
        return scanner.nextLine();
    }

    public static int ingresarNumero(String mensaje) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(mensaje);
            String entrada = scanner.nextLine();
            if (entrada.equals("*")) {
                return -1;
            }
            try {
                int numero = Integer.parseInt(entrada);
                return numero;
            } catch (NumberFormatException e) {
                System.out.println("Formato incorrecto. Ingrese un número válido.");
            }
        }
    }
}
