/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios200francoruggiero;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author fruggiero
 */
public class Exercise206 {
    private ArrayList<Integer> numeros = new ArrayList<>();
    private Random random = new Random();
    public void six(){

        // Generar 25 números aleatorios entre 1 y 1000
        for (int i = 0; i < 25; i++) {
            int numeroAleatorio = random.nextInt(1000) + 1;
            numeros.add(numeroAleatorio);
            System.out.println("Numero {numeroAleatorio} " + numeroAleatorio);
        }

        // Nombre y ruta del archivo
        String nombreArchivo = "numeros.txt";

        // Escribir los números en el archivo
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            for (Integer numero : numeros) {
                writer.write(numero.toString());
                writer.newLine(); // Agregar una nueva línea después de cada número
            }
            System.out.println("Se han escrito los números en el archivo: " + nombreArchivo);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
