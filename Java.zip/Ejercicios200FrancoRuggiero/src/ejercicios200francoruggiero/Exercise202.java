/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios200francoruggiero;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Exercise202 {
    Scanner entry = new Scanner(System.in);
    ArrayList<String> arr = new ArrayList<>();
    ArrayList<String> arr2 = new ArrayList<>();
    private String add;
    private String nombre_archivo = "c:/temporal/colors.txt";
    private int bytes = 0;
    
    public void writeMemory(){
        do {           
            System.out.println("Ingresá un texto : ");
            add = entry.nextLine().toLowerCase();
            
            if(!add.equals("*") && arr.contains(add))
            arr2.add(add);
            
        } while (!add.equals("*")&& arr.contains(add));
    }
    public void writeTxt(){
        arr.add("negro");
        arr.add("azul");
        arr.add("marrón");
        arr.add("gris");
        arr.add("verde");
        arr.add("naranja");
        arr.add("rosa");
        arr.add("púrpura");
        arr.add("rojo");
        arr.add("blanco");
        arr.add("amarillo");
        arr.add("turquesa");
        arr.add("verde oliva");
        arr.add("verde menta");
        arr.add("borgoña");
        arr.add("lavanda");
        arr.add("magenta");
        arr.add("salmón");
        arr.add("cian");
        arr.add("beige");
        arr.add("rosado");
        arr.add("verde oscuro");
        arr.add("verde oliva");
        arr.add("lila");
        arr.add("amarillo pálido");
        arr.add("fucsia");
        arr.add("mostaza");
        arr.add("ocre");
        arr.add("trullo");
        arr.add("malva");
        arr.add("púrpura oscuro");
        arr.add("verde lima");
        arr.add("verde claro");
        arr.add("ciruela");
        arr.add("azul claro");
        arr.add("melocotón");
        arr.add("violeta");
        arr.add("tan");
        arr.add("granate");
    }
    public void saveMemory(){
        try {
            PrintWriter pr = new PrintWriter(new FileWriter(nombre_archivo, true));
            for (int i = 0; i < arr.size(); i++) {
                String linea = arr.get(i);
                pr.println(linea);
                bytes += linea.length();
                System.out.println(linea);
            }
            pr.close();
            System.out.println("Bytes escritos: " + bytes);
        } catch (FileNotFoundException e) {
//            System.out.println(e);
            e.printStackTrace();
        } catch (IOException e) {
//            System.out.println(e);
            e.printStackTrace();
        }
    }
}

