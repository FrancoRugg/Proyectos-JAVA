/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios200francoruggiero;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author fruggiero
 */
public class Exercise203 {
    //Profe, en este mismo no recordaba bien como agregar un elemento para agregar en cola y en internet encontré el Queue(LinkedList).
    
    private Queue<Integer> cola = new LinkedList<>();
    private List<Integer> lista1 = new ArrayList<>();
    private List<Integer> lista2 = new ArrayList<>();
    private List<Integer> lista3 = new ArrayList();

    public void ingresarDato(int dato) {
        cola.offer(dato); // Agregar un dato a la cola
    }

    public void procesarEntrada() {
        lista1.clear(); // Limpiar las listas antes de procesar
        lista2.clear();
        lista3.clear();

        while (!cola.isEmpty()) {
            lista1.add(cola.poll()); // Mover el primer elemento de la cola a lista1
            if (!cola.isEmpty()) {
                lista2.add(cola.poll()); // Mover el siguiente elemento de la cola a lista2
            }
            if (!cola.isEmpty()) {
                lista3.add(cola.poll()); // Mover el siguiente elemento de la cola a lista3
            }
        }
    }

    public void imprimirEntradaSalidas() {
        System.out.println("Entrada (Cola): " + cola);
        System.out.println("Salida Lista 1: " + lista1);
        System.out.println("Salida Lista 2: " + lista2);
        System.out.println("Salida Lista 3: " + lista3);
    }

}
