/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package estructuraswitch;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class EstructuraSwitch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Variable que tome varios valores
        
//        switch (variable) {
//        
//            case valor1:
//                operación;
//                break;
//            
//            case valor2:
//                operación;
//                break;
//            
//            case valor3:
//                operación;
//                break;
//                
//            default:
//                operación;
////                El default no lleva break;
//            
//        }

        Scanner entry = new Scanner(System.in);
        
//        System.out.println("Ingrese un número: ");
//        int number    = entry.nextInt();
        
//        switch (number) {
//        
//            case 1: 
//                System.out.println("Lunes");
//                break;
//                
//            case 2: 
//                System.out.println("Martes");
//                break;
//                
//            case 3: 
//                System.out.println("Miercoles");
//                break;
//                
//            case 4: 
//                System.out.println("Jueves");
//                break;
//                
//            case 5: 
//                System.out.println("Viernes");
//                break;
//                
//            case 6: 
//                System.out.println("Sabado");
//                break;
//                
//            case 7: 
//                System.out.println("Domingo");
//                break;
//                
//            default:
//                System.out.println("El numero ingresado debe de ser <= 7");
//                
//        
//        }
        
//        int i;
//        for( i      = 0; i <100; i++ ){ //Incremento
//        
//            System.out.println("Number " + ( i + 1 ));
//            
//        }
//        
//        for ( int j = 10; j >= 0; j-- ) { //Decremento
//            
//            System.out.println("Number " + ( j ));
//            
//        }
//        
//        for (int j = 0; j < 10; j++) {
//            
//        }

//            System.out.println("Ingrese un número: ");
//            int num        = entry.nextInt();
//            int z          = 1;
//            
//            if      ( num >= 0 ) {
//                
//                for (int i = num; i >= 2; i--) {
//                    
//                    z = (z * i);
//                    
//                    
//                }
//                
//                    System.out.println("El factorial es " + z );
//                                
//            }else{
//            
//                System.out.println("El numero tiene que ser mayor o igual a 0");
//            
//            }
        

           System.out.println("Cuantos numeros queres ingresar: ");
           int cantidad     = entry.nextInt();
           int suma         = 0;
           int negativos    = 0;
           int menor        = 0;
           int mayor        = 0;
           
           for (int j = 1; j <= cantidad; j++) {
            
               System.out.println("Ingresá " + j);
               int total = entry.nextInt();
               
               suma += total;
               
               if( total < 0 ){
               
                   negativos ++;
               
               }
               
               if(j == 1 || total < menor){
               
                   menor = total;
                   
               }
               
               if( j == 1 || total > mayor ) {
               
                   mayor = total;
               
               }
                                                                                                     
        }
               System.out.println("El mayor es " + mayor);
               System.out.println("El menor es " + menor);
               System.out.println("La suma de todos es " + ( suma ) );
               System.out.println("La cantidad de negativos es " + negativos);
               
           
        
        
        
        
    }
    
}
