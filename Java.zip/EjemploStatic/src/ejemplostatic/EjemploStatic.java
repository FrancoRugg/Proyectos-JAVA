/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplostatic;

/**
 *
 * @author fruggiero
 */
public class EjemploStatic {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    //Metodo para llamar a la función creando un objeto!
        Ejemplo ej = new Ejemplo();
        ej.saludar();
    //Metodo para llamar a la función estática!
          Ejemplo.saludar();
    }
    
}
