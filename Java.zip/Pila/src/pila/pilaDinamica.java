/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila;

/**
 *
 * @author fruggiero
 */
public class pilaDinamica<Type> {
    private Nodo<Type> top;
    private int size;
    
    public pilaDinamica(){
        top = null;
        size = 0;
    }
    
    public boolean isEmpty(){
        return top == null;
    }
    
    public int size(){
        return this.size;
    }
    
    public void push(Type element){
        Nodo aux = new Nodo(element, top);
        top = aux;
        size +=1;
    }
    
    //Devuelve el tope del Nodo sin eliminar el elemento.
    public Type peek(){
        if(isEmpty()){
            return null;
        }else{
            return top.getElement();
        }
    }
    
    //Pop, devuelve el tope del Nodo y lo elimina de la pila.
    public Type pop(){
        if(isEmpty()){
            return null;
        }else{
            Type res = top.getElement();
            top = top.getNext();
            size -=1;
            return res;
        }
    }

    @Override
    public String toString() {
        if(!isEmpty()){
            String res = "";
            Nodo aux = top;

            while (aux != null) {
                res += aux.getElement().toString() + "\n";
                aux = aux.getNext();
            }
            return res;
        }else{
            return "Nodo vacio.";
        }
    }
    
    
}
