/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pila;

/**
 *
 * @author fruggiero
 */
public class pilaEstatica {
    private String[] pila;
    private int top;

    public pilaEstatica(int max) {
        pila = new String[max];
        top = -1;
    }
    
    public boolean isEmpty(){
        return top == -1;
    }
    
    public int size(){
        return top + 1;
    }
    
    public void push(String element) throws Exception{
        try {
                top += 1;
                pila[top] = element;
            
        } catch (Exception e) {
            top --;
            String err = "Pila without space. " + e.toString();
            throw new Exception(err);
//            e.printStackTrace();
//            System.out.println(err);
        }
    }
    
    //Devuelve el tope de la pila sin eliminar el elemento.
    public String peek(){
        if(isEmpty()){
            return null;
        }else{
            return pila[top];
        }
    }
    
    //Pop, devuelve el tope de la pila y lo elimina de la pila.
    public String pop(){
        if(isEmpty()){
            return null;
        }else{
            String aux = pila[top]; 
            top -=1;
            pila[top] = null;
            return aux;
        }
    }

    @Override
    public String toString() {
        if(!isEmpty()){
        String res = "";
        for (int i = 0; i < size(); i++) {
            res += pila[i] + "\n";//\n salto de linea
        }
        return res;
        }else{
            return "Pila vacia.";
        }
    }
    
    
    
    
    
}
