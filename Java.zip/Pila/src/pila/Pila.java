/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pila;

import java.util.Stack;

/**
 *
 * @author fruggiero
 */
public class Pila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
//        pilaEstatica pil = new pilaEstatica(5);
//        try {
//            pil.push("pepe");
//            pil.push("lola");
//            pil.push("ana");
//            pil.push("sulma");
//            pil.push("pantera");
//            pil.push("rasconagian");
//        } catch (Exception e) {
//            System.out.println(e.toString());
//        }
//        
//        
////        System.out.println("Desapilo : " + pil.pop());
//        System.out.println("Desapilo sin desapilar: " + pil.peek());
//        
//        System.out.println("Size : " + pil.size());
//        
//        System.out.println("Contain : ");
//        System.out.println(pil.toString());
        pilaDinamica<String> pil = new pilaDinamica();//clase que hicimos
//        Stack<String> pil = new Stack();//clase que hicimos
            pil.push("pepe");
            pil.push("lola");
            pil.push("ana");
            pil.push("sulma");
            pil.push("pantera");
            pil.push("rasconagian");
        
        
        System.out.println("Desapilo : " + pil.pop());
//        System.out.println("Desapilo sin desapilar: " + pil.peek());
        
        System.out.println("Size : " + pil.size());
        
        System.out.println("Contain : ");
        System.out.println(pil.toString());
        
        pilaDinamica<Integer> pil2 = new pilaDinamica();//clase que hicimos
//        Stack<Integer> pil2 = new Stack();//clase que hicimos
            pil2.push(0);
            pil2.push(1);
            pil2.push(2);
            pil2.push(3);
            pil2.push(4);
            pil2.push(5);
        
        
//        System.out.println("Quito elemento : " + pil2.pop());
        System.out.println("Muestro elemento sin quitarlo: " + pil2.peek());
        
        System.out.println("Size : " + pil2.size());
        
        System.out.println("Contain : ");
        System.out.println(pil2.toString());
        
    }
    
}
