/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package matrices;

/**
 *
 * @author fruggiero
 */
public class Matrices {

    /**
     * @param args the command line arguments
     */
        public static int obtenerAleatorio(){
            return (int) (Math.random() * 99);
        }
        
     public static void mostrarMatriz(int[][] matriz) {
        // TODO code application logic here
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " - ");
            }
            System.out.println();
        }
     }
    public static void main(String[] args) {
        // TODO code application logic here
        
        int filas = 6;
        int columnas = 4;
        
       int[][] matriz = new int [filas][columnas]; //así se muestra la matriz
       
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                matriz [i][j] = obtenerAleatorio();
            }
        }
        
        System.out.println("Mostrar original :");
        mostrarMatriz(matriz);
    
        System.out.println("------------------------------");
        
        
        int [][] matrizTranspuesta = new int [columnas][filas];
        
        for (int i = 0; i < matrizTranspuesta.length; i++) {
            for (int j = 0; j < matrizTranspuesta[i].length; j++) {
                matrizTranspuesta [i][j] = obtenerAleatorio();
            }
        }
        System.out.println("Matriz transpuesta :");
        mostrarMatriz(matrizTranspuesta);
        
        // suma de matrices!
        
        int [] [] matriz2 = new int [filas] [columnas] ;
       
        for (int i = 0; i < matriz2.length; i++) {
            for (int j = 0; j < matriz2 [i].length; j++) {
                matriz2 [i] [j] = obtenerAleatorio();
                
            }
        }
            System.out.println("++++++++++++++++++++++++++++");
            System.out.println("matriz 2");
            mostrarMatriz(matriz2);
            
        
        int [] [] matrizSuma = new int [filas] [columnas] ;
       
        for (int i = 0; i < matrizSuma.length; i++) {
            for (int j = 0; j < matrizSuma [i].length; j++) {
                matrizSuma [i] [j] = matriz [i] [j] + matriz2 [i] [j];
            }
       
        }   
        System.out.println("+++++++++++++++++++++++++++++++++++");
        System.out.println("la matriz suma es");
    
        mostrarMatriz( matrizSuma);
    }
}