/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package poosuma;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class PooSuma {
    
    static int resultadoSuma;

    public static void saludar(){
        System.out.println("Bienvenido al programa para sumar!");
    }
    
    public static void sumar(int valor1, int valor2){
        resultadoSuma = valor1 + valor2;
    }
    public static void main(String[] args) {
        saludar();        
        
        Scanner entry    = new Scanner(System.in);
        System.out.println("Ingrese el primer valor: ");
        int valor1 = entry.nextInt();
        
        System.out.println("Ingrese el segundo valor: ");
        int valor2 = entry.nextInt();
        
        sumar(valor1, valor2);
        System.out.println("El resultado es: " + resultadoSuma);
        System.out.println("El resultado de la suma es: " + (valor1 + valor2));
    }
    
}
