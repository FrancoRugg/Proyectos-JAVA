/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package arraylistd05;

import java.util.ArrayList;

/**
 *
 * @author fruggiero
 */
public class values {
    
    
    
    ArrayList<Integer> arr =new ArrayList<>();
    
    public void array(){
        
        
        for(int i = 0; i < 100; i++ ){
        Integer random = (int) (Math.random() * 500);
            arr.add(random);
        }
        
        
    }
    
    public void print(){
        int count = 0;
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                Integer num = arr.get(count);
                
                boolean rep = repeat(arr, num);
                
                if(rep){
                    System.out.print(arr.get(count));
                    System.out.print("x");
                    System.out.print("  ");
                }else{
                    System.out.print(arr.get(count));
                    System.out.print("  ");
                }
//                System.out.print(arr.get(count));
//                System.out.print("  ");
                count ++;
            }
        System.out.println("  " );

        }
    }
    
    public boolean repeat(ArrayList<Integer> arr2, Integer element){
        int trys = 0;
        for (Integer numX: arr2) {
            if(numX.equals(element)){
                trys ++;
            }
        }
        
        if(trys > 1){
            return true;
        }
        
        return false;
    }
        
        
    
}
