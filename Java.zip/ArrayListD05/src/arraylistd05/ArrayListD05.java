/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arraylistd05;


/**
 *
 * @author fruggiero
 */
public class ArrayListD05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Imprime 10 filas random y si el elemento está repetido se le agrega una letra x al lado
        
        values filas = new values();
        
        filas.array();
        filas.print();
        
    }
    
}
