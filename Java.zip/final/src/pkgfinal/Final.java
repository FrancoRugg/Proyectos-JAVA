/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkgfinal;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entry = new Scanner(System.in);
        
        System.out.println("Ingresá un n°: ");
        int lado1 = entry.nextInt();
        System.out.println("Ingresá un segundo n°: ");
        int lado2 = entry.nextInt();
        System.out.println("Ingresá un tercer n°: ");
        int lado3 = entry.nextInt();
        
//        equilatero Todos iguales
//                Isósceles Dos iguales
//                        Escaleno Todos diferentes
        System.out.println("-----------------------------------------");
        System.out.println("Método 1: ");
        int perimetro = lado1 + lado2 + lado3;
        System.out.println("El perimetro del triangulo es : " + perimetro);
        
        
        System.out.println("-----------------------------------------");
        System.out.println("Método 2: ");

        String equilatero = "En base a sus medidas iguales, el triángulo se denomina Equilátero";
        String isosceles = "En base a sus medidas, el triángulo se denomina Isósceles";
        String escaleno = "En base a sus medidas desiguales, el triángulo se denomina Escaleno";
        if(lado1 == lado2 && lado2 == lado3 && lado3 == lado1){
            System.out.println(equilatero);
        }else if( lado1 == lado2 && lado3 != lado1 && lado3 != lado2 || lado2  == lado3 && lado1 != lado3 && lado1 != lado2 ||lado3  == lado1 && lado2 != lado3 && lado2 != lado1){
            System.out.println(isosceles);
        }else{
            System.out.println(escaleno);
        }
    }
}
