/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class positivoNegativo {
    
    public void solution(){
    
        System.out.println("Ejercicio 106");
        
        Scanner positivoNegativo    = new Scanner(System.in);
        
        System.out.println("Ingresá un número: ");
        int number                  = positivoNegativo.nextInt();
        
        if(number < 0){
        
            System.out.println("El número es negativo");
            
        }else if(number > 0){
        
            System.out.println("El número es positivo");
            
        }else{
        
            System.out.println("El número es cero");
        
        }
        
    }
    
}
