/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;
import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class EjerciciosSerieCienFrancoRuggiero {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
//        Documentos Requeridos
//        holaPorCinco mihola                 = new holaPorCinco();
//        mihola.solution();
//        
//        suma misuma                         = new suma();
//        misuma.solution();
//        
//        enteros mienteros                   = new enteros();
//        mienteros.solution();
//        
//        centimetres micentimetres           = new centimetres();
//        micentimetres.solution();
//        
//        area miarea                         = new area();
//        miarea.solution();
//        
//        positivoNegativo mipositivoNegativo = new positivoNegativo();
//        mipositivoNegativo.solution();
//        
//        estacionamiento miestacionamiento   = new estacionamiento();
//        miestacionamiento.solution();
        
        parImpar miparImpar                 = new parImpar();
        miparImpar.solution();
        
//        sOn misOn                           = new sOn();
//        misOn.solution();
//        
//        longitud milongitud                 = new longitud();
//        milongitud.solution();
////        

        
        
        
    }
    
}
