/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class sOn {
    
    public void solution(){
    
        System.out.println("Ejercicio 109");
        
        Scanner sn      = new Scanner(System.in);
        
        System.out.println("Ingrese la clave correcta y será agradecido: ");
        String clave    = sn.nextLine();
        
        if(clave.equals("S")  || clave.equals("N")){
        
            System.out.println("Gracias");
            
        }else{
        
            System.out.println("Mensaje Incorrecto");
        
        }
        
        
    }
    
}
