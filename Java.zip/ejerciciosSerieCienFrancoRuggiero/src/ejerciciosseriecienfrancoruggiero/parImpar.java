/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class parImpar {
    
    public void solution(){
    
        System.out.println("Ejercicio 108");
        
        Scanner total       = new Scanner(System.in);
        
        System.out.println("Ingrese un número : ");
        int number          = total.nextInt();
        
        if( number % 2  == 0){
        
            System.out.println("El número es Par");
        
        }else{
        
            System.out.println("El número es Impar");

        
        }
        
        
    }
    
}
