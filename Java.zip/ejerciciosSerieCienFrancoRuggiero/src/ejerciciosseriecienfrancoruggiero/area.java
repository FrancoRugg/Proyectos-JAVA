/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class area {
 
    public void solution(){
    
        System.out.println("Ejercicio 105");
        
        Scanner area    = new Scanner(System.in);
        
        System.out.println("Ingresá la base : ");
        int base        = area.nextInt();
        
        System.out.println("Ingresá la altura : ");
        int altura      = area.nextInt();
        
        float resultado   = (float)( base * altura ) / 2;
        String mensaje  = "El resultado del area del triangulo es : ";
        System.out.println( mensaje + resultado);
        
    }
    
}
