/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class longitud {
    
    public void solution(){
    
        System.out.println("Ejercicio 110");
        
        Scanner triangle    = new Scanner(System.in);
        
        System.out.println("Ingresá lado 1 : ");
        float lado1         = triangle.nextFloat();
        
        System.out.println("Ingresá lado 2 : ");
        float lado2         = triangle.nextFloat();
        
        System.out.println("Ingresá lado 3 : ");
        float lado3         = triangle.nextFloat();
        
        if( lado1 == lado2 && lado2 == lado3 && lado3 == lado1 ) {
        
            System.out.println("Es un triangulo Equilátero");
        
        }else if(lado1 == lado2 && lado1 != lado3 || lado2 == lado3 && lado2 != lado1 || lado3 == lado1 && lado3 != lado2){
        
            System.out.println("Es un triangulo Isósceles");
        
        }else{
        
            System.out.println("Es un triangulo Escaleno");
           
        }
        
    }
    
}
