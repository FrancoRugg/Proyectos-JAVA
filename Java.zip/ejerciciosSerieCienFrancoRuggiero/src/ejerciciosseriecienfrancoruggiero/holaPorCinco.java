/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

/**
 *
 * @author fruggiero
 */
public class holaPorCinco {
    
    public void solution(){
    
//        Forma Facil
//        System.out.println("Hola");
//        System.out.println("Hola");
//        System.out.println("Hola");
//        System.out.println("Hola");
//        System.out.println("Hola");

//Ciclo For
    System.out.println("Ejercicio 101");
       String i = "Hola";
        for( int o = 0; o < 5; o++){
        
             System.out.println(i);
            
        }
        
    }
    
    
}
