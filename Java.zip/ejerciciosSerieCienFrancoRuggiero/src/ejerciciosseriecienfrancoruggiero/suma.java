/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class suma {
    
    public void solution(){
    
        Scanner suma = new Scanner(System.in);
        
        System.out.println("Ejercicio 102");
        System.out.println("Ingresá el primer número: ");
        int dato          = suma.nextInt();
        
        System.out.println("Ingresá un segundo número: ");
        int dato2         = suma.nextInt();
        
        System.out.println("Ingresá un tercer número: ");
        int dato3         = suma.nextInt();
        
        System.out.println("Ingresá un cuarto número: ");
        int dato4         = suma.nextInt();
        
        System.out.println("Ingresá un quinto número: ");
        int dato5         = suma.nextInt();
        
        int total          = dato + dato2 + dato3 + dato4 +dato5;
        
        System.out.println("La suma total es " + total);
                
    }
    
}
