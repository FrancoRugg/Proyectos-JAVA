/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;

/**
 *
 * @author fruggiero
 */
public class enteros {
    
    public void solution(){
    
        Scanner entero     = new Scanner(System.in);
        
        System.out.println("Ejercicio 103");
        System.out.println("Ingresá un Número : ");
        float number1        = entero.nextFloat();
        
        System.out.println("Ingresá otro un Número : ");
        float number2        = entero.nextFloat();
        
        float suma           = (number1 + number2);
        System.out.println("El resultado de la suma es: " + suma);
        
        float resta          = (number1 - number2);
        System.out.println("El resultado de la resta es: " + resta);
        
        float multiplicacion = (number1 * number2);
        System.out.println("El resultado de la multiplicación es: " + multiplicacion);
        
        float division       = (float)(number1 / number2);
        System.out.println("El resultado de la división es: " + division);
        
        float modulo         = (number1 % number2);
        System.out.println("El resultado del resto del módulo es: " + modulo);
        
        
    }
    
}
