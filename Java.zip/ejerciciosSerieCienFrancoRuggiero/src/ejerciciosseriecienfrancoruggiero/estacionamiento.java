/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciosseriecienfrancoruggiero;

import java.util.Scanner;
/**
 *
 * @author fruggiero
 */
public class estacionamiento {
    
    public void solution(){
    
        System.out.println("Ejercicio 107");
        
        Scanner estacionamiento         = new Scanner(System.in);

        int primerHora  = 700;
        int post        = 500;
        int hora        = 1;
        int totalHoras;
        System.out.println("Ingresar total de horas que utilizó el estacionaminto : " ) ;
        float tiempo    = estacionamiento.nextFloat();
        
        if( tiempo == 1 ){
        
            System.out.println("El cliente debe pagar $" + ( tiempo * primerHora ) ) ;
        
        }else if( tiempo > 1 ){ //Funciona en el caso de que se marquen horas exactas, le agradecería si me ayuda a realizarlo para que tome cualquier horario(Ej: 1:30);  
            
            System.out.println("El cliente debe pagar $" + ( primerHora + ( ( tiempo - 1 ) * post ) ) ) ;
        
        }
    }
    
}
